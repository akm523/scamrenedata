#coding: utf-8
import sys
from semi_lda import SemiLDA
from util import ArgUtil
import csv
TRAIN_INDX = 5
TEST_INDX = 5
LABEL_INDEX = 5
def dataset(datasetFilePath):
    csvfile = open(datasetFilePath, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    dataset = []
    for row in reader:
        dataset.append(row)
    return dataset

def accuracy():
    datas = dataset("semi_test.csv")

    # Here, 0: corrective
    # 1: perfective
    # 2: preventive or adaptive
    correct_tot = 0
    adap_tot = 0
    prevent_tot = 0
    perfect_tot = 0
    total = 0
    correct_y = 0
    correct_de = 0
    adap_y = 0
    adap_de = 0
    prevent_y = 0
    prevent_de = 0
    perfect_y = 0
    perfect_de = 0
    category = ["corrective", "perfective", "adaptive", "preventive"]
    prediction = []
    i = 0
    ii = 0
    print(len(datas))
    adap = 0
    for line in open("output.txt"):
        lnn = line.split(":")[0]
        print(lnn)

        # if(lnn not in category):
        #    continue
        if (lnn in "corrective"):
            correct_de = correct_de + 1
        elif (lnn in "preventive"):
            prevent_de = prevent_de + 1
        elif (lnn in "adaptive" or lnn in "preventive"):
            adap_de = adap_de + 1
        elif (lnn in "perfective"):
            perfect_de = perfect_de + 1
        else:
            continue

        if (datas[i][2].lower() in "corrective"):
            correct_tot = correct_tot + 1
        elif (datas[i][2].lower() in "preventive"):
            prevent_tot = prevent_tot + 1
        elif (datas[i][2].lower() in "adaptive" or datas[i][2].lower() in "preventive"):
            adap_tot = adap_tot + 1
        elif (datas[i][2].lower() in "perfective"):
            perfect_tot = perfect_tot + 1
        else:
            continue

        if (lnn in datas[i][2].lower()):
            if (lnn in "adaptive"):
                adap += 1
            if (lnn in "corrective"):
                correct_y = correct_y + 1
            if (lnn in "preventive"):
                prevent_y = prevent_y + 1
            if (lnn in "adaptive" or lnn in "preventive"):
                adap_y = adap_y + 1
            if (lnn in "perfective"):
                perfect_y = perfect_y + 1
            ii += 1
        i += 1
    print(correct_de)
    print(adap_de)
    print(prevent_de)
    print(perfect_de)
    print("total: ", str(i))
    print("Accuracy: ", str(ii))
    if (correct_y > 0):
        correct_f1 = F1Caclculate(correct_y, correct_de, correct_tot)

        print("correct_f1: ", correct_f1)
    if (adap_y > 0):
        adap_f1 = F1Caclculate(adap_y, adap_de, adap_tot)
        print("adap_f1: ", adap_f1)
    #if (prevent_y > 0):
    #    prevent_f1 = F1Caclculate(prevent_y, prevent_de, prevent_tot)
    #    print("prevent_f1: ", prevent_f1)

    if (perfect_y > 0):
        perfect_f1 = F1Caclculate(perfect_y, perfect_de, perfect_tot)
        print("perfect_f1: ", perfect_f1)
    print("Accuracy: ", str(ii))
    print("Accuracy: ", str(ii))
def F1Caclculate(accurate, detected, total):
    p = accurate/detected
    print("precisin: %s" %p)
    r = accurate/total
    f1 = 2*(p*r/(p+r))
    return f1
def accuracyAC():
    datas = dataset("semi_test.csv")


    # Here, 0: corrective
    # 1: perfective
    # 2: preventive or adaptive
    correct_tot = 0
    adap_tot = 0
    prevent_tot = 0
    perfect_tot = 0
    total = 0
    correct_y = 0
    correct_de = 0
    adap_y = 0
    adap_de = 0
    prevent_y = 0
    prevent_de = 0
    perfect_y = 0
    perfect_de = 0
    category = ["corrective", "perfective", "adaptive", "preventive"]
    prediction = []
    i = 0
    ii = 0
    print(len(datas))
    adap=0
    for line in open("output.txt"):
        lnn = line.split(":")[0]
        lnn = lnn.lower()
        print(lnn)

        #if(lnn not in category):
        #    continue
        if (lnn in "corrective"):
            correct_de = correct_de + 1
        elif (lnn in "preventive"):
            prevent_de = prevent_de + 1
        elif (lnn in "adaptive"):
            adap_de = adap_de + 1
        elif (lnn in "perfective"):
            perfect_de = perfect_de + 1
        else:
            continue

        if (datas[i][2].lower() in "corrective"):
            correct_tot = correct_tot + 1
        elif (datas[i][2].lower() in "preventive"):
            prevent_tot = prevent_tot + 1
        elif (datas[i][2].lower() in "adaptive"):
            adap_tot = adap_tot + 1
        elif (datas[i][2].lower() in "perfective"):
            perfect_tot = perfect_tot + 1
        else:
            continue


        if(lnn in datas[i][2].lower() ):
            if(lnn in "adaptive"):
                adap +=1
            if (lnn in "corrective"):
                correct_y = correct_y + 1
            if (lnn in "preventive"):
                prevent_y = prevent_y + 1
            if (lnn in "adaptive"):
                adap_y = adap_y + 1
            if (lnn in "perfective"):
                perfect_y = perfect_y + 1
            ii +=1
        i += 1
    print(correct_de)
    print(adap_de)
    print(prevent_de)
    print(perfect_de)
    print("total: ", str(i))
    print("Accuracy: ", str(ii))
    if (correct_y > 0):
        correct_f1 = F1Caclculate(correct_y, correct_de, correct_tot)

        print("correct_f1: ", correct_f1)
    if (adap_y > 0):
        adap_f1 = F1Caclculate(adap_y, adap_de, adap_tot)
        print("adap_f1: ", adap_f1)
    if (prevent_y > 0):
        prevent_f1 = F1Caclculate(prevent_y, prevent_de, prevent_tot)
        print("prevent_f1: ", prevent_f1)

    if (perfect_y > 0):
        perfect_f1 = F1Caclculate(perfect_y, perfect_de, perfect_tot)
        print("perfect_f1: ", perfect_f1)
    print("Accuracy: ", str(ii))
    print(adap)


def main():
    arg_util = ArgUtil()
    cmd_args = arg_util.parse_infer_args()

    lda = SemiLDA(cmd_args, 'infer')
    lda.infer()  
    #accuracy()
    accuracyAC()
if __name__ == '__main__':
    main()
