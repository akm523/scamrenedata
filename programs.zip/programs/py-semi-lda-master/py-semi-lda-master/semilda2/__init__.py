#coding: utf-8

_version_ = '0.1'

_module_name_ = 'semi-lda'

def Version():
    print '%s %s' % (_version_, _module_name_)

