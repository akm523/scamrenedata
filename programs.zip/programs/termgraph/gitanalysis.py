from git import Repo
import time
import git, os, shutil
import csv
import ast
import sys
import nltk
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import networkx as nx
import string
from sys import maxint
from decimal import *

reload(sys)
sys.setdefaultencoding('utf-8')

getcontext().prec = 3
DIR_NAME = "temp"
REMOTE_URL = "https://github.com/galaxyproject/galaxy"
VESRION_NUM = "DE-ui-1.9.5-RELEASE"
PATH = "/media/akm523/ACA88097A8806226/labwork/data/de_ui/"
REPO_PATH = "/media/akm523/ACA88097A8806226/labwork/data/de/DE/"
G_TAGS = ['v13.02','v13.04', 'v13.08', 'v13.11', 'v14.06', 'v14.08', 'v14.10', 'v15.01', 'v15.05', 'v16.04', 'v17']
vers = ['13/galaxy-13.02.1', '13/galaxy-13.08.1', '14/galaxy-14.04.1', '14/galaxy-14.06.1', '14/galaxy-14.08.1', '15/galaxy-15.01.4', '15/galaxy-15.03.4', '16/galaxy-16.01', '16/galaxy-16.04', '16/galaxy-16.10' ]
BUG_COUNT = 0
UI_WORDS = ["UI","user interface","menu","textbox","checkbox","display","view","visualization","model","verify"]

SACCS = ['enhancement', 'improvement', 'structur', 'defect', 'architectur', 'module', 'functional', 'change', 'refactor', 'subsystem', 'dynamic', 'runtime', 'resource', 'usability', 'reliability', 'portability', 'availability', 'maintainability', 'scalability', 'efficiency','component','performance' 'concurrent', 'process', 'dependency','layer', 'relationship', 'inheritance', 'import', 'couplin', 'decompose', 'layer', 'performance', 'thread', 'distributed']
csv.field_size_limit(sys.maxsize)
def filteredCommit():
    remo = git.Remote("https://github.com/galaxyproject/galaxy.git", "galaxy")

    r_repo = remo.repo
    print(r_repo)
    # rorepo is a Repo instance pointing to the git-python repository.
    # For all you know, the first argument to Repo is a path to the repository
    # you want to work with
    repo = Repo(REPO_PATH)
    # git = repo.git
    # git.checkout('HEAD', b="v13.02.1")
    # print(repo.tag('refs/tags/v13.02.1'))
    # fifty_first_commits = list(repo.iter_commits('v13.02.1', max_count=5))
    #
    # for commt in fifty_first_commits
    #     print(commt.message)

    csvfile = open(PATH + VESRION_NUM + "_changes.csv", 'rb')
    # spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    # csvf = StringIO(csvfile.read().decode("utf8"))
    reader = csv.reader(csvfile, delimiter=b',')
    docs = ""
    count = 0
    fl = open(PATH + VESRION_NUM + "_commits.csv", 'wb')
    csv_write = csv.writer(fl)

    for row in reader:
        if (row[0] != ' ' or row is not None and "added" not in row[5]):

            files_str = row[2]
            files = ast.literal_eval(files_str)
            for file in files:
                if ("__init__" not in file or "test" not in file):
                    relative_path = REPO_PATH + row[1] + "/" + row[0] + "/" + file
                    print(relative_path)
                    commits_touching_path = list(repo.iter_commits(paths=relative_path))

                    for commit in commits_touching_path:

                        csv_write.writerow([row[0], commit.message, commit.committed_date])
                        # print(time.strftime("%a, %d %b %Y %H:%M", time.gmtime(commit.committed_date)))

                        # print(commit.message)
def removeStop(word_list):
    filtered_word_list = word_list[:]  # make a copy of the word_list
    for word in word_list:  # iterate over word_list

        if word in stopwords.words('english'):
            if (word is not "in" and  word is not "out" and word is not "into" and word is not "to"):
                filtered_word_list.remove(word)
    return filtered_word_list
                        # print(commit.message)

def removeStopOrigin(word_list):
    filtered_word_list = word_list[:]  # make a copy of the word_list
    for word in word_list:  # iterate over word_list

        if word in stopwords.words('english'):
            filtered_word_list.remove(word)
    return filtered_word_list

def commitsFromVersion(version):
    repo = Repo(REPO_PATH)
    fifty_first_commits = list(repo.iter_commits(version))



    # csvfile = open(PATH + VESRION_NUM + "_changes.csv", 'rb')
    # reader = csv.reader(csvfile, delimiter=b',')
    # docs = ""
    # count = 0
    fl = open(PATH + VESRION_NUM + "_commits.csv", 'wb')
    csv_write = csv.writer(fl)
    for commit in fifty_first_commits:

        csv_write.writerow([commit.name_rev ,commit.message, commit.committed_date])

def filterByTime(commit_dat, filepath):
    csvfile = open(filepath, 'rb')
    date_list=[]
    reader = csv.reader(csvfile, delimiter=b',')
    for row in reader:
        #print(row[2])
        #print(time.strftime("%a, %d %b %Y %H:%M", time.gmtime(float(row[2]))))
        get_time = time.strftime("%Y-%m-%d", time.gmtime(float(row[2])))
        if(commit_dat<get_time):
            print(get_time)

def filterBugs(filepath):
    csvfile = open(filepath + "galaxy_commits.csv", 'rb')
    fl = open(filepath + "bugcommits"+".csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    for row in reader:
        if("fix" in row[1] or "bug" in row[1] or "error" in row[1] or "fixup" in row[1] or "fail" in row[1]):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3]])
def filterSACCcommit(filepath, tag):
    global  SACCS
    # csvfile = open(filepath + "galaxy_commits.csv", 'rb')
    # fl = open(filepath + "saccscommits"+".csv", 'wb')
    tag_part = tag
    if ("ui" in tag):
        parts = tag.split('/')
        tag_part = parts[1] + "_" + parts[2]
    csvfile = open(filepath + tag_part+"_version.csv", 'rb')
    fl = open(filepath + tag_part + "_saccscommits" + ".csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    for row in reader:
        issaac = 0
        saacwords = []
        for saac in SACCS:
            if(saac in row[1]):
                issaac = 1
                saacwords.append(saac)
        if(issaac==1):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3], saacwords])

def filterByTag(tag, filepath):
    csvfile = open(filepath + "imagej_commits.csv", 'rb')
    tag_part = tag
    if("ui" in tag):
        parts = tag.split('/')
        tag_part = parts[1] +"_" + parts[2]
    fl = open(filepath + tag_part+"_version.csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    count = 0
    for row in reader:
        if(tag in row[0]):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3]])
            count = count + 1
    print("{} {}".format(tag, count))
def filterBugsByTag(tag, filepath):
    csvfile = open(filepath + "bugcommits.csv", 'rb')
    fl = open(filepath + tag+"_l.csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    count  = 0
    for row in reader:
        if(tag in row[0]):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3]])
            count = count + 1
    print("Tag:{} Count:{}".format(tag, str(count)))

def matchChangeCommits(changefile, commitfile):
    global  BUG_COUNT
    csvfile = open(changefile, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    commitcsv = open(commitfile, 'rb')
    commitreader = csv.reader(commitcsv, delimiter=b',')
    for row in reader:
        if (row[0] != ' ' and row is not None and  "added" not in row[5]):
            print(row[5])
            # for commit in commitreader:
            #             files_str = commit[2]
            #             commited_files = ast.literal_eval(files_str)
            #             # print(commited_files)
            #             for c_file in commited_files:
            #                 # print(c_file)
            #                 if(row[0] in c_file):
            #                     print(commit[1])
            #                     break


            files_str = row[2]
            files = ast.literal_eval(files_str)
            for file in files:
                if ( "test" not in file):
                    relative_path = file
                    # print(relative_path)
                    if(file == "__init__"):
                        relative_path =row[0] + "/" + file

                    for commit in commitreader:
                        files_str = commit[2]
                        commited_files = ast.literal_eval(files_str)
                        # print(commited_files)
                        for c_file in commited_files:
                            # print(c_file)
                            if(relative_path in c_file):
                                print("Version:{} Commit:{}".format(changefile,commit[1]))
                                BUG_COUNT = BUG_COUNT + 1
                                break


def wordStemming(example_words):
    ps = PorterStemmer()
    words = []
    for w in example_words:
        wd = str(w)
        words.append(ps.stem(wd))
    return words

def termGraph(term_list):
    dG = nx.DiGraph()
    for term in term_list:
        termlist = term.split()
        termlist2 = [string.rstrip(x.lower(), ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        termlist3 = removeStop(termlist2)
        wordList2 = wordStemming(termlist3)
        # print(wordList2)
        edge_weight = len(wordList2)
        for i, word in enumerate(wordList2):
            word = str(word)

            try:
                next_word = str(wordList2[i + 1])

                if not dG.has_node(word):
                    dG.add_node(word)
                    dG.node[word]['count'] = 1
                else:
                    dG.node[word]['count'] += 1
                if not dG.has_node(next_word):
                    dG.add_node(next_word)
                    dG.node[next_word]['count'] = 0

                if not dG.has_edge(word, next_word):
                    dG.add_edge(word, next_word, weight=edge_weight)
                else:

                    weight = int(dG.edge[word][next_word]['weight'])
                    if(weight>edge_weight):
                        dG.edge[word][next_word]['weight'] = edge_weight
            except IndexError:
                if not dG.has_node(word):
                    dG.add_node(word)
                    dG.node[word]['count'] = 1
                else:
                    dG.node[word]['count'] += 1
            except:
                raise
    # for edge in dG.edges():
    #     print '%s:%d\n' % (edge, maxint - dG.edge[edge[0]][edge[1]]['weight'])
    return dG

def termGraphGeneration(file_path, commit_path, save_path):
    global UI_WORDS
    stem_ui = wordStemming(UI_WORDS)
    example = "Relocate DefaultAppService in ij-platform module This brings the AppService interface together with its DefaultAppService implementation, eliminating the prior nasty situation where AppService is on the classpath without any suitable implementations thereof. " \
              "Add API to wrap existing plugin in a module" \
              "This is takes the form of a new method of PluginModuleFactory, as well" \
              "as a new PluginModuleInfo#createModule(RunnablePlugin) method."
    csvcommit = open(commit_path, 'rb')
    commit_reader = csv.reader(csvcommit, delimiter=b',')
    csvfile = open(file_path, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    fl = open( save_path, 'wb')
    csv_write = csv.writer(fl)
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    dG = termGraph(terms)

    shortest_path = nx.shortest_path(dG, source='reloc', target='modul', weight='weight')
    print(shortest_path)
    shortest_paths = nx.shortest_path(dG, source='improv', weight='weight')
    print(shortest_paths)
    print(dG.successors('design'))
    # for edge in dG.edges():
    #     print '%s:%d\n' % (edge, dG.edge[edge[0]][edge[1]]['weight'])


    for commit_row in commit_reader:
        example = commit_row[1]
        samples = example.split(".")
        found_sample = False
        for sample in samples:

            example_dg = termGraph([sample])
            found_edge = False
            for edge in dG.edges():
                try:

                    source_node = edge[0]
                    dest_node = edge[1]
                    all_paths = nx.shortest_path(example_dg, source=source_node, target=dest_node)
                    keyterm_weight = int(dG.edge[edge[0]][edge[1]]['weight'])

                    if(keyterm_weight>2):

                        source_connected_nodes = dG.predecessors(source_node)
                        dest_connected_nodes  = dG.successors(dest_node)
                        if(keyterm_weight == 3):
                            for source in source_connected_nodes:
                                if(example_dg.has_node(source)):
                                    found_edge = True
                                    break
                            if(found_edge ==False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        found_edge = True
                                        break
                        elif(keyterm_weight == 4):
                            num_nodes = 2
                            for source in source_connected_nodes:
                                if (example_dg.has_node(source)):
                                    num_nodes = 3
                                    connected_pred = dG.predecessors(source)
                                    for last_pred in connected_pred:
                                        if (example_dg.has_node(last_pred)):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                            if (found_edge == False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        if(num_nodes == 3):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                                        connected_succ = dG.successors(dest)
                                        for last_succ in connected_succ:
                                            if (example_dg.has_node(last_succ)):
                                                num_nodes = 4
                                                found_edge = True
                                                break
                        if(found_edge):
                            print("weight: {}".format(keyterm_weight))
                            print("Matched edge {}".format(edge))
                            print("found path {}".format(all_paths))
                            break
                    else:
                        found_edge = True
                        print("Matched edge {}".format(edge))
                        for ui_word in stem_ui:
                            if(ui_word in all_paths):
                                found_edge = False
                                break
                        print("found path {}".format(all_paths))

                        break
                except:
                    asd = 0
            if(found_edge):
                found_sample = True
                break
        if(found_sample):
            csv_write.writerow([commit_row[0] , commit_row[1] ,commit_row[2], commit_row[3]])

def readTerms(file_path):
    csvfile = open(file_path, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    return terms

def uniqueTerms(save_path, terms):
    fl = open( save_path, 'wb')
    csv_write = csv.writer(fl)
    unique_word = set()
    for term in terms:
        termlist = term.split()
        termlist2 = [string.rstrip(x.lower(), ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        termlist3 = removeStopOrigin(termlist2)
        #wordList2 = wordStemming(termlist3)
        for key_word in termlist3:
            if(key_word not in unique_word):
                unique_word.add(key_word)
                csv_write.writerow([key_word])

def termSignificance(terms, filepath, save_path):

    csvfile = open(filepath, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    fl = open(save_path, 'wb')
    csv_write = csv.writer(fl)
    commits =[]
    print(" C(T)-- AC(T) -- N(T)--act/ac")
    for row in reader:
        commits.append(row)
    #ct = len(commits)
    for term in terms:
        act = 0
        ct = 0
        ac = 0
        nt = 0
        wor = wordStemming([term])
        for commit in commits:
            text = commit[1]
            YN = commit[4]
            termlist = text.split()
            termlist2 = [string.rstrip(x.lower(), ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
            termlist3 = removeStopOrigin(termlist2)
            wordList2 = wordStemming(termlist3)
            wor = wordStemming([term])

            if(wor[0] in wordList2):
                ct = ct +1
                if("Yes" in YN):
                    act = act +1
                else: nt = nt+1
            if("Yes" in YN):
                ac = ac + 1

        #sig = float(float(act/(ct*1)) + float(act/(ac*1)) - float(nt/(act*1)))

        if(nt == 0):
            powr =  float(Decimal(act)/Decimal(ac*1))
        else:
            powr = float(Decimal(act)/Decimal(ac*1) + Decimal(act)/Decimal(nt*1))
            if(act == 0):
                act = 1
            #powr = float(Decimal(act)/Decimal(ac*1) - Decimal(nt)/Decimal(act*1))
        if(powr>0.0):
            csv_write.writerow([wor[0], act, nt, powr])
            #print(wor[0] + " " + str(ct) + " " + str(act) + " " + str(nt) + " "+str(float((act*100)/(ac*1)))+" "+ str(powr))
if __name__ == "__main__":
    #nltk.download("stopwords")
    #commitsFromVersion('ui/1.9.5-RELEASE')
    #%Y-%m-%d'
    LPATH = '/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/13/'
    LVERSION ='galaxy-13.02.1'
    #filterByTime("2013-02-08", LPATH + LVERSION + "_commits.csv")
    #filterBugs("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/")
    # for tag in G_TAGS:
    #     filterByTag(tag, "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/" )
    # filterByTag("v2.0.0-beta4", "/media/akm523/ACA88097A8806226/labwork/data/imageJ_release/")
    #matchChangeCommits("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/14/"+"galaxy-14.06.1_changes.csv", "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/"+"v14.08.csv")
    # for tag in G_TAGS[:1]:
    #     filterBugsByTag(tag, "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/")
    # for version in vers:
    #     matchChangeCommits("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/"+version + "_changes.csv", "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/"+"bugcommits.csv")
    #
    # print("Bug count: {}".format(str(BUG_COUNT)))
    #filterSACCcommit("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/")

    # filterSACCcommit("/media/akm523/ACA88097A8806226/labwork/data/imageJ_release/", "v2.0.0-beta4")
    saccslist = ["Design", "improvement","improve","improving","enhancement","enhancing","enhance","installing","install","deploy","deploying","deployment","extend","Extended","extending"]
    # wordStemming(saccslist)

    wrd = ["i", "move", "every", "into", "in", "out","split","add", "new"]
    # removeStop(wrd)
    choice = input("Enter your choice: ")
    if (choice == 1):
        uniqueTerms("/media/akm523/ACA88097A8806226/labwork/data/architerm.csv",readTerms("/media/akm523/ACA88097A8806226/labwork/data/saccsterm.csv"))
    if(choice == 2):
        termSignificance(readTerms("/media/akm523/ACA88097A8806226/labwork/forked_worked/archidata/archichange/goldenset/architerm.csv"), "/media/akm523/ACA88097A8806226/labwork/forked_worked/archidata/archichange/goldenset/annotated.csv", "/media/akm523/ACA88097A8806226/labwork/forked_worked/archidata/archichange/goldenset/term_power.csv")
    if(choice == 3):
        termGraphGeneration("C:\labwork\forked_worked\archidata\archichange\goldenset\saccsterm.csv", "C:\labwork\data\Hibernate_data\hibernate_commits.csv", "C:\labwork\data\Hibernate_data\saccs_commit.csv")
