import time
import csv
import ast
import codecs
import sys
import nltk
import matplotlib.pyplot as plt
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import networkx as nx
import string
#from sys import maxint
from decimal import *
csv.field_size_limit(500 * 1024 * 1024)
DIR_NAME = "temp"
REMOTE_URL = "https://github.com/galaxyproject/galaxy"
VESRION_NUM = "DE-ui-1.9.5-RELEASE"
PATH = "/media/akm523/ACA88097A8806226/labwork/data/de_ui/"
REPO_PATH = "/media/akm523/ACA88097A8806226/labwork/data/de/DE/"
G_TAGS = ['v13.02','v13.04', 'v13.08', 'v13.11', 'v14.06', 'v14.08', 'v14.10', 'v15.01', 'v15.05', 'v16.04', 'v17']
vers = ['13/galaxy-13.02.1', '13/galaxy-13.08.1', '14/galaxy-14.04.1', '14/galaxy-14.06.1', '14/galaxy-14.08.1', '15/galaxy-15.01.4', '15/galaxy-15.03.4', '16/galaxy-16.01', '16/galaxy-16.04', '16/galaxy-16.10' ]
BUG_COUNT = 0
UI_WORDS = ["UI","user interface","menu","textbox","checkbox","display","view","visualization","model","verify"]

SACCS = ['enhancement', 'improvement', 'structur', 'defect', 'architectur', 'module', 'functional', 'change', 'refactor', 'subsystem', 'dynamic', 'runtime', 'resource', 'usability', 'reliability', 'portability', 'availability', 'maintainability', 'scalability', 'efficiency','component','performance' 'concurrent', 'process', 'dependency','layer', 'relationship', 'inheritance', 'import', 'couplin', 'decompose', 'layer', 'performance', 'thread', 'distributed']
#csv.field_size_limit(sys.maxsize)
import re
caps = "([A-Z])"
prefixes = "(Mr|St|Mrs|Ms|Dr)[.]"
suffixes = "(Inc|Ltd|Jr|Sr|Co)"
starters = "(Mr|Mrs|Ms|Dr|He\s|She\s|It\s|They\s|Their\s|Our\s|We\s|But\s|However\s|That\s|This\s|Wherever)"
acronyms = "([A-Z][.][A-Z][.](?:[A-Z][.])?)"
websites = "[.](com|net|org|io|gov)"

def split_into_sentences(text):
    text = " " + text + "  "
    text = text.replace("\n"," ")
    text = re.sub(prefixes,"\\1<prd>",text)
    text = re.sub(websites,"<prd>\\1",text)
    if "Ph.D" in text: text = text.replace("Ph.D.","Ph<prd>D<prd>")
    text = re.sub("\s" + caps + "[.] "," \\1<prd> ",text)
    text = re.sub(acronyms+" "+starters,"\\1<stop> \\2",text)
    text = re.sub(caps + "[.]" + caps + "[.]" + caps + "[.]","\\1<prd>\\2<prd>\\3<prd>",text)
    text = re.sub(caps + "[.]" + caps + "[.]","\\1<prd>\\2<prd>",text)
    text = re.sub(" "+suffixes+"[.] "+starters," \\1<stop> \\2",text)
    text = re.sub(" "+suffixes+"[.]"," \\1<prd>",text)
    text = re.sub(" " + caps + "[.]"," \\1<prd>",text)
    if "”" in text: text = text.replace(".”","”.")
    if "\"" in text: text = text.replace(".\"","\".")
    if "!" in text: text = text.replace("!\"","\"!")
    if "?" in text: text = text.replace("?\"","\"?")
    text = text.replace(".",".<stop>")
    text = text.replace("?","?<stop>")
    text = text.replace("!","!<stop>")
    text = text.replace("<prd>",".")
    sentences = text.split("<stop>")
    sentences = sentences[:-1]
    sentences = [s.strip() for s in sentences]
    return sentences
def removeStop(word_list):
    filtered_word_list = word_list[:]  # make a copy of the word_list
    for word in word_list:  # iterate over word_list

        if word in stopwords.words('english'):
            if (word is not "in" and  word is not "out" and word is not "into" and word is not "to"):
                filtered_word_list.remove(word)
    return filtered_word_list
                        # print(commit.message)

def removeStopOrigin(word_list):
    filtered_word_list = word_list[:]  # make a copy of the word_list
    for word in word_list:  # iterate over word_list

        if word in stopwords.words('english'):
            filtered_word_list.remove(word)
    return filtered_word_list

def checkPurity(word):
    PURE = True
    for cha in word:
        if (cha not in string.ascii_letters):
            PURE = False
            break
    return PURE

def filterByTime(commit_dat, filepath):
    csvfile = open(filepath, 'rb')
    date_list=[]
    reader = csv.reader(csvfile, delimiter=b',')
    for row in reader:
        #print(row[2])
        #print(time.strftime("%a, %d %b %Y %H:%M", time.gmtime(float(row[2]))))
        get_time = time.strftime("%Y-%m-%d", time.gmtime(float(row[2])))
        if(commit_dat<get_time):
            print(get_time)

def filterBugs(filepath):
    csvfile = open(filepath + "galaxy_commits.csv", 'rb')
    fl = open(filepath + "bugcommits"+".csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    for row in reader:
        if("fix" in row[1] or "bug" in row[1] or "error" in row[1] or "fixup" in row[1] or "fail" in row[1]):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3]])
def filterSACCcommit(filepath, tag):
    global  SACCS
    # csvfile = open(filepath + "galaxy_commits.csv", 'rb')
    # fl = open(filepath + "saccscommits"+".csv", 'wb')
    tag_part = tag
    if ("ui" in tag):
        parts = tag.split('/')
        tag_part = parts[1] + "_" + parts[2]
    csvfile = open(filepath + tag_part+"_version.csv", 'rb')
    fl = open(filepath + tag_part + "_saccscommits" + ".csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    for row in reader:
        issaac = 0
        saacwords = []
        for saac in SACCS:
            if(saac in row[1]):
                issaac = 1
                saacwords.append(saac)
        if(issaac==1):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3], saacwords])

def filterByTag(tag, filepath):
    csvfile = open(filepath + "imagej_commits.csv", 'rb')
    tag_part = tag
    if("ui" in tag):
        parts = tag.split('/')
        tag_part = parts[1] +"_" + parts[2]
    fl = open(filepath + tag_part+"_version.csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    count = 0
    for row in reader:
        if(tag in row[0]):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3]])
            count = count + 1
    print("{} {}".format(tag, count))
def filterBugsByTag(tag, filepath):
    csvfile = open(filepath + "bugcommits.csv", 'rb')
    fl = open(filepath + tag+"_l.csv", 'wb')
    csv_write = csv.writer(fl)
    reader = csv.reader(csvfile, delimiter=b',')
    count  = 0
    for row in reader:
        if(tag in row[0]):
            csv_write.writerow([row[0] , row[1] ,row[2], row[3]])
            count = count + 1
    print("Tag:{} Count:{}".format(tag, str(count)))

def matchChangeCommits(changefile, commitfile):
    global  BUG_COUNT
    csvfile = open(changefile, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    commitcsv = open(commitfile, 'rb')
    commitreader = csv.reader(commitcsv, delimiter=b',')
    for row in reader:
        if (row[0] != ' ' and row is not None and  "added" not in row[5]):
            print(row[5])
            # for commit in commitreader:
            #             files_str = commit[2]
            #             commited_files = ast.literal_eval(files_str)
            #             # print(commited_files)
            #             for c_file in commited_files:
            #                 # print(c_file)
            #                 if(row[0] in c_file):
            #                     print(commit[1])
            #                     break


            files_str = row[2]
            files = ast.literal_eval(files_str)
            for file in files:
                if ( "test" not in file):
                    relative_path = file
                    # print(relative_path)
                    if(file == "__init__"):
                        relative_path =row[0] + "/" + file

                    for commit in commitreader:
                        files_str = commit[2]
                        commited_files = ast.literal_eval(files_str)
                        # print(commited_files)
                        for c_file in commited_files:
                            # print(c_file)
                            if(relative_path in c_file):
                                print("Version:{} Commit:{}".format(changefile,commit[1]))
                                BUG_COUNT = BUG_COUNT + 1
                                break


def wordStemming(example_words):
    ps = PorterStemmer()
    words = []
    for w in example_words:
        wd = str(w)
        words.append(ps.stem(wd))
    return words

def termGraph(term_list):
    dG = nx.DiGraph()
    for term in term_list:
        termlist = term.split()
        termlist2 = []
        for x in termlist:
             if (checkPurity(x) == True):
                 termlist2.append(x.lower())
        termlist3 = removeStop(termlist2)
        wordList2 = wordStemming(termlist3)
        # print(wordList2)
        edge_weight = len(wordList2)
        for i, word in enumerate(wordList2):
            word = str(word)

            try:
                next_word = str(wordList2[i + 1])

                if not dG.has_node(word):
                    dG.add_node(word)
                    dG.node[word]['count'] = 1
                else:
                    dG.node[word]['count'] += 1
                if not dG.has_node(next_word):
                    dG.add_node(next_word)
                    dG.node[next_word]['count'] = 0

                if not dG.has_edge(word, next_word):
                    dG.add_edge(word, next_word, weight=edge_weight)
                else:
                    #print(dG.edges[word,next_word]['weight'])
                    weight = int(dG.edges[word,next_word]['weight'])
                    if(weight>edge_weight):
                        dG.edges[word,next_word]['weight'] = edge_weight
            except IndexError:
                if not dG.has_node(word):
                    dG.add_node(word)
                    dG.node[word]['count'] = 1
                else:
                    dG.node[word]['count'] += 1
            except:
                raise
    # for edge in dG.edges():
    #     print '%s:%d\n' % (edge, maxint - dG.edge[edge[0]][edge[1]]['weight'])
    return dG

def termGraphGeneration(file_path, commit_path, save_path):
    global UI_WORDS
    stem_ui = wordStemming(UI_WORDS)
    example = "Relocate DefaultAppService in ij-platform module This brings the AppService interface together with its DefaultAppService implementation, eliminating the prior nasty situation where AppService is on the classpath without any suitable implementations thereof. " \
              "Add API to wrap existing plugin in a module" \
              "This is takes the form of a new method of PluginModuleFactory, as well" \
              "as a new PluginModuleInfo#createModule(RunnablePlugin) method."
    print("detection started")
    csvfile = open(commit_path, 'r' , encoding="utf8",errors='ignore')
    commit_reader = csv.reader(csvfile, delimiter=',')
    csvfile = open(file_path, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    fl = open( save_path, 'w')
    csv_write = csv.writer(fl)
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    dG = termGraph(terms)
    '''
    plt.subplot(211)
    nx.draw(dG, with_labels=True,node_size =400, node_color='b', font_size=8)
    plt.show()

    shortest_path = nx.shortest_path(dG, source='api', target='improv', weight='weight')
    print(shortest_path)
    shortest_paths = nx.shortest_path(dG, source='improv', weight='weight')
    print(shortest_paths)

    #print(dG.successors('design'))
    for edge in dG.edges():
        print('%s:%d\n' % (edge, dG.edges[edge[0],edge[1]]['weight']))
    exit(0)
    '''
    accuracy = 0
    total = 0
    for commit_row in commit_reader:
        example = commit_row[1]
        samples = example.split(".")
        #print(len(samples))
        found_sample = False
        for sample in samples:

            example_dg = termGraph([sample])
            found_edge = False
            for edge in dG.edges():
                try:

                    source_node = edge[0]
                    dest_node = edge[1]
                    all_paths = nx.shortest_path(example_dg, source=source_node, target=dest_node)
                    keyterm_weight = int(dG.edges[edge[0],edge[1]]['weight'])

                    if(keyterm_weight>2):

                        source_connected_nodes = dG.predecessors(source_node)
                        dest_connected_nodes  = dG.successors(dest_node)
                        if(keyterm_weight == 3):
                            for source in source_connected_nodes:
                                if(example_dg.has_node(source)):
                                    found_edge = True
                                    break
                            if(found_edge ==False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        found_edge = True
                                        break
                        elif(keyterm_weight == 4):
                            num_nodes = 2
                            for source in source_connected_nodes:
                                if (example_dg.has_node(source)):
                                    num_nodes = 3
                                    connected_pred = dG.predecessors(source)
                                    for last_pred in connected_pred:
                                        if (example_dg.has_node(last_pred)):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                            if (found_edge == False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        if(num_nodes == 3):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                                        connected_succ = dG.successors(dest)
                                        for last_succ in connected_succ:
                                            if (example_dg.has_node(last_succ)):
                                                num_nodes = 4
                                                found_edge = True
                                                break
                        if(found_edge):
                            print("weight: {}".format(keyterm_weight))
                            print("Matched edge {}".format(edge))
                            print("found path {}".format(all_paths))
                            break
                    else:
                        found_edge = True
                        print("Matched edge {}".format(edge))
                        for ui_word in stem_ui:
                            if(ui_word in all_paths):
                                found_edge = False
                                break
                        print("found path {}".format(all_paths))

                        break

                except Exception as err:
                    asd = 0
                    #print("<<------------Problem occured--------------->> %s" %err)
            if(found_edge):
                found_sample = True
                break
        if(found_sample):
            total +=1
            print("Sample should write")
            csv_write.writerow([commit_row[0] , commit_row[1] ,commit_row[2]])#, commit_row[3]])
            if("not_manually_classified" not in commit_row[2]):
                accuracy +=1
    print("accur;;; %s"%str(accuracy))
    print("total;;; %s" % str(total))



def awareness(aware_str):
    aware = False
    if("not_aware:FALSE" in aware_str):
        aware = True
    return aware

def changeAware(aware_str):
    aware = False
    if("not_aware:FALSE" in aware_str):
        aware = True
    return aware

def termGraphAware(file_path, commit_path, save_path):
    global UI_WORDS
    stem_ui = wordStemming(UI_WORDS)
    example = "Relocate DefaultAppService in ij-platform module This brings the AppService interface together with its DefaultAppService implementation, eliminating the prior nasty situation where AppService is on the classpath without any suitable implementations thereof. " \
              "Add API to wrap existing plugin in a module" \
              "This is takes the form of a new method of PluginModuleFactory, as well" \
              "as a new PluginModuleInfo#createModule(RunnablePlugin) method."
    print("detection started")
    csvfile = open(commit_path, 'r' , encoding="utf8",errors='ignore')
    commit_reader = csv.reader(csvfile, delimiter=',')
    csvfile = open(file_path, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    fl = open( save_path, 'w')
    csv_write = csv.writer(fl)
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    dG = termGraph(terms)

    '''
    plt.subplot(211)
    nx.draw(dG, with_labels=True,node_size =400, node_color='b', font_size=8)
    plt.show()

    shortest_path = nx.shortest_path(dG, source='api', target='improv', weight='weight')
    print(shortest_path)
    shortest_paths = nx.shortest_path(dG, source='improv', weight='weight')
    print(shortest_paths)

    #print(dG.successors('design'))
    for edge in dG.edges():
        print('%s:%d\n' % (edge, dG.edges[edge[0],edge[1]]['weight']))
    exit(0)
    '''
    all_manual = 0
    manual = 0
    aware = 0
    set_data = 0
    accuracy = 0
    total = 0
    is_aware = 0
    total_aware=0
    for commit_row in commit_reader:
        example = commit_row[1]
        if(commit_row[3] =='' or "not_computed" in commit_row[3]):
            continue
        set_data +=1
        if(1.50 <extractChangeMetric(commit_row[3])):
            aware +=1
        if(awareness(commit_row[2])):
            total_aware +=1
        if("not_manually_classified" not in commit_row[2]):
            all_manual +=1
        #nltk.download('punkt')

        samples = example.split(". ") #re.split(r' *[\.\?!][\'"\)\]]* *', example)#split_into_sentences(example)#sent_tokenize(example)#

        #print(len(samples))
        found_sample = False
        for sample in samples:

            example_dg = termGraph([sample])
            found_edge = False
            for edge in dG.edges():
                try:

                    source_node = edge[0]
                    dest_node = edge[1]
                    all_paths = nx.shortest_path(example_dg, source=source_node, target=dest_node)
                    keyterm_weight = int(dG.edges[edge[0],edge[1]]['weight'])

                    if(keyterm_weight>2):

                        source_connected_nodes = dG.predecessors(source_node)
                        dest_connected_nodes  = dG.successors(dest_node)
                        if(keyterm_weight == 3):
                            for source in source_connected_nodes:
                                if(example_dg.has_node(source)):
                                    found_edge = True
                                    break
                            if(found_edge ==False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        found_edge = True
                                        break
                        elif(keyterm_weight == 4):
                            num_nodes = 2
                            for source in source_connected_nodes:
                                if (example_dg.has_node(source)):
                                    num_nodes = 3
                                    connected_pred = dG.predecessors(source)
                                    for last_pred in connected_pred:
                                        if (example_dg.has_node(last_pred)):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                            if (found_edge == False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        if(num_nodes == 3):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                                        connected_succ = dG.successors(dest)
                                        for last_succ in connected_succ:
                                            if (example_dg.has_node(last_succ)):
                                                num_nodes = 4
                                                found_edge = True
                                                break
                        if(found_edge):
                            print("weight: {}".format(keyterm_weight))
                            print("Matched edge {}".format(edge))
                            print("found path {}".format(all_paths))
                            break
                    else:
                        found_edge = True
                        print("Matched edge {}".format(edge))
                        for ui_word in stem_ui:
                            if(ui_word in all_paths):
                                found_edge = False
                                break
                        print("found path {}".format(all_paths))

                        break

                except Exception as err:
                    asd = 0
                    #print("<<------------Problem occured--------------->> %s" %err)
            if(found_edge):
                found_sample = True
                break
        if(found_sample):
            total +=1
            print("Sample should write")
            csv_write.writerow([commit_row[0] , commit_row[1] ,commit_row[2]])#, commit_row[3]])
            if( 1.50 < extractChangeMetric(commit_row[3])):
                accuracy +=1
            if(awareness(commit_row[2])):
                is_aware +=1
            if ("not_manually_classified" not in commit_row[2]):
                manual +=1
    print("accur-- %s"%str(accuracy))
    print("detected-- %s" % str(total))
    print("set-- %s" % str(set_data))
    print("change-- %s" % str(aware))
    print("is_aware--- %s"%is_aware)
    print("total_aware--- %s" % total_aware)
    print("total_manualk--- %s" % all_manual)
    print("manual--- %s" % manual)



def termGraphTest(file_path, commit_path, save_path):
    global UI_WORDS
    stem_ui = wordStemming(UI_WORDS)
    example = "Relocate DefaultAppService in ij-platform module This brings the AppService interface together with its DefaultAppService implementation, eliminating the prior nasty situation where AppService is on the classpath without any suitable implementations thereof. " \
              "Add API to wrap existing plugin in a module" \
              "This is takes the form of a new method of PluginModuleFactory, as well" \
              "as a new PluginModuleInfo#createModule(RunnablePlugin) method."
    print("detection started")
    csvfile = open(commit_path, 'r' , encoding="utf8",errors='ignore')
    commit_reader = csv.reader(csvfile, delimiter=',')
    csvfile = open(file_path, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    fl = open( save_path, 'w')
    csv_write = csv.writer(fl)
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    dG = termGraph(terms)

    '''
    plt.subplot(211)
    nx.draw(dG, with_labels=True,node_size =400, node_color='white', font_color='black', alpha=0.65,edge_color="grey", font_size=8)
    plt.figure(3, figsize=(42, 42), dpi=180)
    plt.show()

    shortest_path = nx.shortest_path(dG, source='api', target='improv', weight='weight')
    print(shortest_path)
    shortest_paths = nx.shortest_path(dG, source='improv', weight='weight')
    print(shortest_paths)

    #print(dG.successors('design'))
    for edge in dG.edges():
        print('%s:%d\n' % (edge, dG.edges[edge[0],edge[1]]['weight']))
    exit(0)
    '''
    detected_no = 0
    acurate_no = 0
    set_data = 0
    accuracy_ac = 0
    total_ac = 0
    total_no=0
    detected_ac = 0
    for commit_row in commit_reader:
        example = commit_row[1]
        if(commit_row[5] =='na' or "Na" in commit_row[5]):
            continue
        set_data +=1
        if ("yes" in commit_row[4].lower()):
            total_ac +=1
        if ("no" in commit_row[4].lower()):
            total_no +=1
        #nltk.download('punkt')

        samples = example.split(". ") #re.split(r' *[\.\?!][\'"\)\]]* *', example)#split_into_sentences(example)#sent_tokenize(example)#

        #print(len(samples))
        found_sample = False
        for sample in samples:

            example_dg = termGraph([sample])
            found_edge = False
            for edge in dG.edges():
                try:

                    source_node = edge[0]
                    dest_node = edge[1]
                    all_paths = nx.shortest_path(example_dg, source=source_node, target=dest_node)
                    keyterm_weight = int(dG.edges[edge[0],edge[1]]['weight'])

                    if(keyterm_weight>2):

                        source_connected_nodes = dG.predecessors(source_node)
                        dest_connected_nodes  = dG.successors(dest_node)
                        if(keyterm_weight == 3):
                            for source in source_connected_nodes:
                                if(example_dg.has_node(source)):
                                    found_edge = True
                                    break
                            if(found_edge ==False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        found_edge = True
                                        break
                        elif(keyterm_weight == 4):
                            num_nodes = 2
                            for source in source_connected_nodes:
                                if (example_dg.has_node(source)):
                                    num_nodes = 3
                                    connected_pred = dG.predecessors(source)
                                    for last_pred in connected_pred:
                                        if (example_dg.has_node(last_pred)):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                            if (found_edge == False):
                                for dest in dest_connected_nodes:
                                    if (example_dg.has_node(dest)):
                                        if(num_nodes == 3):
                                            num_nodes = 4
                                            found_edge = True
                                            break
                                        connected_succ = dG.successors(dest)
                                        for last_succ in connected_succ:
                                            if (example_dg.has_node(last_succ)):
                                                num_nodes = 4
                                                found_edge = True
                                                break
                        if(found_edge):
                            print("weight: {}".format(keyterm_weight))
                            print("Matched edge {}".format(edge))
                            print("found path {}".format(all_paths))
                            break
                    else:
                        found_edge = True
                        print("Matched edge {}".format(edge))
                        for ui_word in stem_ui:
                            if(ui_word in all_paths):
                                found_edge = False
                                break
                        print("found path {}".format(all_paths))

                        break

                except Exception as err:
                    asd = 0
                    #print("<<------------Problem occured--------------->> %s" %err)
            if(found_edge):
                found_sample = True
                break
        if(found_sample):
            detected_ac +=1
            print("Sample should write")
            csv_write.writerow([commit_row[0] , commit_row[1] ,commit_row[2],'yes'])#, commit_row[3]])
            if("yes" in commit_row[4].lower()):
                accuracy_ac +=1
        else:
            csv_write.writerow([commit_row[0], commit_row[1], commit_row[2], 'no'])
            detected_no +=1
            if ("no" in commit_row[4].lower()):
                acurate_no += 1
    print("accur-- %s"%str(accuracy_ac))
    print("detected-- %s" % str(detected_ac))

    print("set-- %s" % str(set_data))
    print("total_yes--- %s" % total_ac)
    y_f1 = F1Caclculate(accuracy_ac, detected_ac, total_ac)
    print("total_no--- %s" % total_no)
    print("acurate no--- %s" % acurate_no)
    print("detected no--- %s" % detected_no)
    n_f1 = F1Caclculate(acurate_no, detected_no, total_no)
    f1  = (y_f1 + n_f1)/2
    #f1 = F1Caclculate(accuracy_ac+acurate_no, detected_ac+detected_no, total_no+ total_ac)
    p = ((accuracy_ac/detected_ac) + (acurate_no/detected_no))/2
    print("F1: %s"%f1)
    print("P: %s"% p)

def extractChangeMetric(change):
    change_list = change.split(";")
    str_coupling = change_list[0].split(":")
    str_cohesion = change_list[len(change_list)-1].split(":")
    #print(str_coupling)
    metric = abs(float(str_coupling[1])) + abs(float(str_cohesion[1]))
    #print(metric)
    return metric
def readTerms(file_path):
    csvfile = open(file_path, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    return terms

def uniqueTerms(save_path, terms):
    fl = open( save_path, 'wb')
    csv_write = csv.writer(fl)
    unique_word = set()
    for term in terms:
        termlist = term.split()
        termlist2 = [string.rstrip(x.lower(), ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        termlist3 = removeStopOrigin(termlist2)
        #wordList2 = wordStemming(termlist3)
        for key_word in termlist3:
            if(key_word not in unique_word):
                unique_word.add(key_word)
                csv_write.writerow([key_word])

def termSignificance(terms, filepath, save_path):

    csvfile = open(filepath, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    fl = open(save_path, 'wb')
    csv_write = csv.writer(fl)
    commits =[]
    print(" C(T)-- AC(T) -- N(T)--act/ac")
    for row in reader:
        commits.append(row)
    #ct = len(commits)
    for term in terms:
        act = 0
        ct = 0
        ac = 0
        nt = 0
        wor = wordStemming([term])
        for commit in commits:
            text = commit[1]
            YN = commit[4]
            termlist = text.split()
            termlist2 = [string.rstrip(x.lower(), ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
            termlist3 = removeStopOrigin(termlist2)
            wordList2 = wordStemming(termlist3)
            wor = wordStemming([term])

            if(wor[0] in wordList2):
                ct = ct +1
                if("Yes" in YN or 'yes' in YN):
                    act = act +1
                else: nt = nt+1
            if("Yes" in YN or 'yes' in YN):
                ac = ac + 1

        #sig = float(float(act/(ct*1)) + float(act/(ac*1)) - float(nt/(act*1)))

        if(nt == 0):
            powr =  float(Decimal(act)/Decimal(ac*1))
        else:
            powr = float(Decimal(act)/Decimal(ac*1) + Decimal(act)/Decimal(nt*1))
            if(act == 0):
                act = 1
            #powr = float(Decimal(act)/Decimal(ac*1) - Decimal(nt)/Decimal(act*1))
        if(powr>0.0):
            csv_write.writerow([wor[0], act, nt, powr])
            #print(wor[0] + " " + str(ct) + " " + str(act) + " " + str(nt) + " "+str(float((act*100)/(ac*1)))+" "+ str(powr))
def readFolder(path, save_path):
    from os import listdir
    from os.path import isfile, join
    fl = open( save_path, 'w')
    csv_write = csv.writer(fl)
    onlyfiles = [f for f in listdir(path) if isfile(join(path, f))]
    print(str(len(onlyfiles)))
    all = 0
    for fils in onlyfiles:
        file = codecs.open(path + "/" +fils, 'r', 'utf-8', errors='ignore')
        keywords = ""
        name = str(fils.split('.')[0])

        try:
            all +=1
            keywords = [line.strip() for line in file]
        except Exception as err:
            asd = 0
        print(".......%s" % name)
        csv_write.writerow([name, " ".join(keywords)])
    print(str(all))
    return onlyfiles

def F1Caclculate(accurate, detected, total):
    p = accurate/detected
    r = accurate/total
    f1 = 2*(p*r/(p+r))
    return f1


if __name__ == "__main__":
    #nltk.download("stopwords")
    #commitsFromVersion('ui/1.9.5-RELEASE')
    #%Y-%m-%d'
    LPATH = '/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/13/'
    LVERSION ='galaxy-13.02.1'
    #filterByTime("2013-02-08", LPATH + LVERSION + "_commits.csv")
    #filterBugs("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/")
    # for tag in G_TAGS:
    #     filterByTag(tag, "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/" )
    # filterByTag("v2.0.0-beta4", "/media/akm523/ACA88097A8806226/labwork/data/imageJ_release/")
    #matchChangeCommits("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/14/"+"galaxy-14.06.1_changes.csv", "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/"+"v14.08.csv")
    # for tag in G_TAGS[:1]:
    #     filterBugsByTag(tag, "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/")
    # for version in vers:
    #     matchChangeCommits("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/"+version + "_changes.csv", "/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/"+"bugcommits.csv")
    #
    # print("Bug count: {}".format(str(BUG_COUNT)))
    #filterSACCcommit("/media/akm523/ACA88097A8806226/labwork/data/galaxy2_release/")

    # filterSACCcommit("/media/akm523/ACA88097A8806226/labwork/data/imageJ_release/", "v2.0.0-beta4")
    saccslist = ["Design", "improvement","improve","improving","enhancement","enhancing","enhance","installing","install","deploy","deploying","deployment","extend","Extended","extending"]
    # wordStemming(saccslist)

    wrd = ["i", "move", "every", "into", "in", "out","split","add", "new"]
    # removeStop(wrd)
    choice = int(input("Enter your choice: "))
    if (choice == 1):
        uniqueTerms("/media/akm523/ACA88097A8806226/labwork/data/architerm.csv",readTerms("/media/akm523/ACA88097A8806226/labwork/data/saccsterm.csv"))
    if(choice == 2):
        termSignificance(readTerms("/media/akm523/ACA88097A8806226/labwork/forked_worked/archidata/archichange/goldenset/architerm.csv"), "/media/akm523/ACA88097A8806226/labwork/forked_worked/archidata/archichange/goldenset/annotated.csv", "/media/akm523/ACA88097A8806226/labwork/forked_worked/archidata/archichange/goldenset/term_power.csv")
    if(choice == 3):
        termGraphAware("C:/labwork/forked_worked/archidata/archichange/goldenset/saccsterm.csv", "C:/labwork/forked_worked/archidata/archichange/goldenset/javaclient.csv", "C:/labwork/data/Hibernate_data/saccs_javaclient.csv")
    if(choice == 4):
        print(readFolder("C:/labwork/forked_worked/archidata/archichange/reviews_files/reviews_files/egit","C:/labwork/forked_worked/archidata/archichange/reviews_files/reviews_files/egit.csv"))
    if (choice == 5):
        termGraphTest("C:/labwork/forked_worked/archidata/archichange/goldenset/saccsterm.csv",
                       "C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/test/iplant.csv",
                       "C:/labwork/forked_worked/archidata/archichange/goldenset/detect_saccs.csv")
    if(choice==6):
        print(F1Caclculate(23, 56, 40))
