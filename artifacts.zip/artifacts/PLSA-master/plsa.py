from numpy import zeros, int8, log
from pylab import random
import sys
from wordsegment import load, segment
import tfdf
#import jieba
import re
import time
import codecs
import string
import csv
from decimal import *
import numpy as np
import nltk
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
csv.field_size_limit(2**16)
# segmentation, stopwords filtering and document-word matrix generating
# [return]:
# N : number of documents
# M : length of dictionary
# word2id : a map mapping terms to their corresponding ids
# id2word : a map mapping ids to terms
# X : document-word matrix, N*M, each line is the number of terms that show up in the document
#nltk.download("stopwords")
from itertools import chain, combinations
correct_tot = 0
adap_tot = 0
prevent_tot = 0
perfect_tot=0
adaptive_path = "adaptive.dic"
corrective_path="corrective.dic"
perfective_path="perfective.dic"
preventive_path="preventive.dic"
allwords_path="allkey.txt"
TRAIN_INDX = 5
TEST_INDX = 5
def checkPurity(word):
    PURE = True
    for cha in word:
        if (cha not in string.ascii_letters):
            PURE = False
            break
    return PURE

def findsubsets(S,m):
    return set(combinations(S, m))

def powerset(iterable):
    """
    powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)
    """
    xs = list(iterable)
    # note we return an iterator rather than a list
    return chain.from_iterable(combinations(xs,n) for n in range(len(xs)+1))

def removeStopOrigin(word_list):
    filtered_word_list = word_list[:]  # make a copy of the word_list
    for word in word_list:  # iterate over word_list

        if word in stopwords.words('english'):
            filtered_word_list.remove(word)
    return filtered_word_list
def wordStemming(example_words):
    ps = PorterStemmer()
    words = []
    for w in example_words:
        wd = str(w)
        words.append(ps.stem(wd))
    return words

def readTerms(file_path):
    csvfile = open(file_path, 'r' , encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    return terms

def uniqueTerms(save_path, terms):
    fl = open( save_path, 'w')
    csv_write = csv.writer(fl)
    unique_word = set()
    for term in terms:
        termlist = term.split()
        termlist2 = [x.lower().strip(',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        termlist3 = removeStopOrigin(termlist2)
        wordList2 = wordStemming(termlist3)
        for key_word in wordList2:
            if(key_word not in unique_word):
                unique_word.add(key_word)
                csv_write.writerow([key_word])
    return list(unique_word)

def termSignificance(terms, filepath, save_path):

    csvfile = open(filepath, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    fl = open(save_path, 'wb')
    csv_write = csv.writer(fl)
    commits =[]
    print(" C(T)-- AC(T) -- N(T)--act/ac")
    for row in reader:
        commits.append(row)
    #ct = len(commits)
    for term in terms:
        act = 0
        ct = 0
        ac = 0
        nt = 0
        wor = wordStemming([term])
        for commit in commits:
            text = commit[1]
            YN = commit[4]
            termlist = text.split()
            termlist2 = [x.lower().strip( ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
            termlist3 = removeStopOrigin(termlist2)
            wordList2 = wordStemming(termlist3)
            wor = wordStemming([term])

            if(wor[0] in wordList2):
                ct = ct +1
                if("Yes" in YN):
                    act = act +1
                else: nt = nt+1
            if("Yes" in YN):
                ac = ac + 1

        #sig = float(float(act/(ct*1)) + float(act/(ac*1)) - float(nt/(act*1)))

        if(nt == 0):
            powr =  float(Decimal(act)/Decimal(ac*1))
        else:
            powr = float(Decimal(act)/Decimal(ac*1) + Decimal(act)/Decimal(nt*1))
            if(act == 0):
                act = 1
            #powr = float(Decimal(act)/Decimal(ac*1) - Decimal(nt)/Decimal(act*1))
        if(powr>0.0):
            csv_write.writerow([wor[0], act, nt, powr])
            #print(wor[0] + " " + str(ct) + " " + str(act) + " " + str(nt) + " "+str(float((act*100)/(ac*1)))+" "+ str(powr))

def probability(terms, doclistpath, save_path):
    csvfile = open(doclistpath, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N = 0
    wordCounts = [];
    occured = {}
    notoccured = {}
    allterms  = {}
    currentId = 0;
    cwd = {}
    print(terms)
    fl = open(save_path, 'w')
    csv_write = csv.writer(fl)
    for key in terms:
        occured[key] = currentId
        notoccured[key] = currentId
        allterms[key] = currentId
    ysample = 0
    nsample = 0
    allsample = 0
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:
        #load()
        cd = 0

        cwd['perfective'] = 0
        cwd['adaptive'] = 0
        cwd['corrective'] = 0

        termlist = document[1].split()
        segList = [x.lower().strip(',.!?;)\(}{[]<>@#$%&^*~|-_=+\n') for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        #print(segList)
        #segList = jieba.cut(document)
        wordCount = {}
        if("yes" in document[4].lower()):
            ysample =ysample +1
        else:
            nsample = nsample +1

        for keyword in terms:
            for word in segList:
                #word = word.lower().strip()
                #print(word)
                word = word.lower().strip()
                #if len(word) > 1 and not re.search('[0-9]', word) and word not in stopwords:
                if(keyword  in word):
                    cd  = cd +1
                    if("yes" in document[4]):
                        occured[keyword] +=1


                    else:
                        notoccured[keyword] +=1

                    allterms[keyword] +=1
                    break
        allsample +=1
    print(ysample)
    for term in terms:
        py = float(occured[term]/ysample)
        npy = float(notoccured[term]/nsample)
        #all = float(allterms[term]/allsample)
        csv_write.writerow([term, py, npy, (py-npy)])


def cwdcdMeasure(wordlistpath, doclistpath, type):

    file = codecs.open(wordlistpath, 'r', 'utf-8')
    keywords = [key.strip() for key in file]
    #keywords = wordStemming(keywords)
    file.close()
    csvfile = open(doclistpath, 'r' , encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N = 0
    wordCounts = [];
    word2id = {}
    id2word = {}
    currentId = 0;
    cwd = {}
    for key in keywords:
        word2id[key] = currentId
        id2word[currentId] = key

        currentId = currentId+1
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:
        #load()
        cd = 0

        cwd['perfective'] = 0
        cwd['adaptive'] = 0
        cwd['corrective'] = 0

        termlist = document[1].split()
        segList = [x.lower() for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        #print(segList)
        #segList = jieba.cut(document)
        wordCount = {}

        for keyword in keywords:
            for word in segList:
                word = word.lower().strip()
                if(checkPurity(word) == True):
                    if(keyword  in word):
                        cd  = cd +1
                        if keyword in wordCount:
                            wordCount[keyword] += 1
                        else:
                            wordCount[keyword] = 1
                        if("corrective" in document[TRAIN_INDX]):
                            cwd['corrective'] += 1
                        if("perfective" in document[TRAIN_INDX]):
                            cwd['perfective'] += 1
                        if("adaptive" in document[TRAIN_INDX] or "preventive" in document[TRAIN_INDX]):
                            cwd['adaptive'] += 1

        #if(len(wordCount)>0):
        wordCounts.append(wordCount)
        print(cwd)
        print(cd)
        cd = 1 if(cd==0) else cd
        lamda[N][0] = float(Decimal(cwd['corrective'])/Decimal(cd))
        lamda[N][1] =  float(Decimal(cwd['perfective'])/Decimal(cd))
        lamda[N][2] = float(Decimal(cwd['adaptive'])/Decimal(cd))
        N=N+1
    # length of dictionary
    M = len(keywords)

    # generate the document-word matrix
    X = zeros([N, M], int8)
    for word in word2id.keys():
        j = word2id[word]
        for i in range(0, N):
            if word in wordCounts[i]:
                X[i, j] = wordCounts[i][word];

    print(X)
    print(lamda)

    return N, M, word2id, id2word, X
def preprocessing(datasetFilePath, stopwordsFilePath):
    
    # read the stopwords file
    file = codecs.open(stopwordsFilePath, 'r', 'utf-8')
    stopwords = [line.strip() for line in file]
    # for doc in stopwords[:5]:
    #     print(doc)
    file.close()
    
    # read the documents
    file = codecs.open(datasetFilePath, 'r', 'utf-8')
    documents = [document.strip() for document in file]

    file.close()

    # number of documents
    N = len(documents)

    wordCounts = [];
    word2id = {}
    id2word = {}
    currentId = 0;
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    for document in documents:
        load()
        segList= segment(document)

        #segList = jieba.cut(document)
        wordCount = {}
        for word in segList:
            word = word.lower().strip()
            if len(word) > 1 and not re.search('[0-9]', word) and word not in stopwords:               
                if word not in word2id.keys():
                    word2id[word] = currentId;
                    id2word[currentId] = word;
                    currentId += 1;
                if word in wordCount:
                    wordCount[word] += 1
                else:
                    wordCount[word] = 1
        wordCounts.append(wordCount);
        print(wordCount)
    # length of dictionary
    M = len(word2id)  

    # generate the document-word matrix
    X = zeros([N, M], int8)
    for word in word2id.keys():
        j = word2id[word]
        for i in range(0, N):
            if word in wordCounts[i]:
                X[i, j] = wordCounts[i][word];    

    return N, M, word2id, id2word, X

def initializeParameters():
    #for i in range(0, N):
    #   normalization = sum(lamda[i, :])
    #    for j in range(0, K):
    #       lamda[i, j] /= normalization;

    for i in range(0, K):
        normalization = sum(theta[i, :])
        for j in range(0, M):
            theta[i, j] /= normalization;

def thetaMeasure(wordlistpath, doclistpath, type):
    file = codecs.open('stopwords.dic', 'r', 'utf-8')
    stopwords = [line.strip() for line in file]
    # for doc in stopwords[:5]:
    #     print(doc)
    file.close()
    file = codecs.open(wordlistpath, 'r', 'utf-8')
    keywords = [key.strip() for key in file]
    keywords = wordStemming(keywords)
    file.close()
    # read the documents
    file = codecs.open(corrective_path, 'r', 'utf-8')
    corrective_key = [corr.strip() for corr in file]
    corrective_key = wordStemming(corrective_key)
    file.close()
    file = codecs.open(adaptive_path, 'r', 'utf-8')
    adaptive_key = [corr.strip() for corr in file]
    adaptive_key = wordStemming(adaptive_key)
    file.close()
    file = codecs.open(perfective_path, 'r', 'utf-8')
    perfective_key = [corr.strip() for corr in file]
    perfective_key = wordStemming(perfective_key)
    file.close()
    csvfile = open(doclistpath, 'r' , encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N = 0
    wordCounts = [];
    word2id = {}
    id2word = {}
    currentId = 0;
    thetacd_perfective= {}
    thetacd_adaptive= {}
    thetacd_corrective= {}
    notthetacd_perfective= {}
    notthetacd_adaptive= {}
    notthetacd_corrective= {}
    for key in keywords:
        thetacd_perfective[key] = 0
        thetacd_adaptive[key]= 0
        thetacd_corrective[key] = 0
        notthetacd_perfective[key] = 0
        notthetacd_adaptive [key]= 0
        notthetacd_corrective[key] = 0
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:
        #load()
        cd = 0


        termlist = document[1].split()
        segList = [x.lower() for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        #print(segList)
        #segList = jieba.cut(document)
        wordCount = {}

        for keyword in keywords:
            for word in segList:
                word = word.lower().strip()
                if(checkPurity(word) == True):
                    if(keyword  in word):
                        cd  = cd +1
                        if keyword not in word2id.keys():
                            word2id[keyword] = currentId;
                            id2word[currentId] = keyword;
                            currentId += 1;
                        if keyword in wordCount:
                            wordCount[keyword] += 1
                        else:
                            wordCount[keyword] = 1
                        if("corrective" in document[TRAIN_INDX].lower() and keyword in corrective_key):
                            thetacd_corrective[keyword] += 1
                        else:  notthetacd_corrective[keyword] += 1
                        if("perfective" in document[TRAIN_INDX].lower() and keyword in perfective_key):
                            thetacd_perfective[keyword] += 1
                        else: notthetacd_perfective[keyword] += 1
                        if("adaptive" in document[TRAIN_INDX].lower() or "preventive" in document[TRAIN_INDX].lower() and keyword in adaptive_key):
                            thetacd_adaptive[keyword] += 1
                        else: notthetacd_adaptive[keyword] += 1

        #if(len(wordCount)>0):
        m = 0

        for key in keywords:
            theta[0][m] += thetacd_corrective[key] if(notthetacd_corrective[key]==0) else thetacd_corrective[key]/notthetacd_corrective[key]
            theta[1][m] +=thetacd_perfective[key] if(notthetacd_perfective[key] == 0) else thetacd_perfective[key]/notthetacd_perfective[key]
            theta[2][m] += thetacd_adaptive[key] if(notthetacd_adaptive[key] == 0) else thetacd_adaptive[key] /notthetacd_adaptive[key]
            m = m+1

        print(theta)
def EStep():
    for i in range(0, N):
        for j in range(0, M):
            denominator = 0;
            for k in range(0, K):
                p[i, j, k] = theta[k, j] * lamda[i, k];
                denominator += p[i, j, k];
            if denominator == 0:
                for k in range(0, K):
                    p[i, j, k] = 0;
            else:
                for k in range(0, K):
                    p[i, j, k] /= denominator;

def MStep():
    # update theta
    for k in range(0, K):
        denominator = 0
        for j in range(0, M):
            #theta[k, j] = 0
            for i in range(0, N):
                theta[k, j] += X[i, j] * p[i, j, k]
            denominator += theta[k, j]
        if denominator == 0:
            for j in range(0, M):
                theta[k, j] = 1.0 / M
        else:
            for j in range(0, M):
                theta[k, j] /= denominator
        
    # update lamda
    for i in range(0, N):
        for k in range(0, K): #Number of topics
            lamda[i, k] = 0
            denominator = 0
            for j in range(0, M):
                lamda[i, k] += X[i, j] * p[i, j, k] # X contain all key-terms count in all samples
                denominator += X[i, j]
            if denominator == 0:
                lamda[i, k] = 1.0 / K
            else:
                lamda[i, k] /= denominator

def predict(sampl):

    # update theta
    for k in range(0, K):
        denominator = 0
        for j in range(0, M):
            theta[k, j] = 0
            for i in range(0, N):
                theta[k, j] += sampl[j] * p[i, j, k]
            denominator += theta[k, j]
        if denominator == 0:
            for jj in range(0, M):
                theta[k, jj] = 1.0 / M
        else:
            for j2 in range(0, M):
                theta[k, j2] /= denominator
    sum =0
    indx = 0
    sumk = np.sum(theta, axis=1)
    for k in range(0,K):
        if(sum< sumk[k]):
            sum = sumk[k]
            indx = k
    return indx
# calculate the log likelihood
def LogLikelihood():
    loglikelihood = 0
    for i in range(0, N):
        for j in range(0, M):
            tmp = 0
            for k in range(0, K):
                tmp += theta[k, j] * lamda[i, k]
            if tmp > 0:
                loglikelihood += X[i, j] * log(tmp)
    return loglikelihood

# output the params of model and top words of topics to files
def acCommits(terms, file_path):

    csvfile = open(file_path, 'r', encoding="utf8",errors='ignore' )
    reader = csv.reader(csvfile, delimiter=',')
    yasample = 0
    miss = 0
    for doc in reader:
        tfidfvalue = tfdf.tfidf([doc[1]])
        sum = 0.0
        #print(tfidfvalue)
        for term in terms:

            if(term in tfidfvalue):
                sum +=tfidfvalue[term]
        if((sum)>0.07):
            if("yes" in doc[4]):
                yasample +=1
            else: miss +=1
    print("Total correct: " + str(yasample))
    print(miss)
def testSamples(wordlistpath, doclistpath):
    file = codecs.open('stopwords.dic', 'r', 'utf-8')
    stopwords = [line.strip() for line in file]
    # for doc in stopwords[:5]:
    #     print(doc)
    file.close()
    file = codecs.open(wordlistpath, 'r', 'utf-8')
    keywords = [key.strip() for key in file]
    keywords = wordStemming(keywords)
    file.close()
    # read the documents
    csvfile = open(doclistpath, 'r', encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N_test = 0
    wordCounts = [];
    word2id = {}
    id2word = {}
    currentId = 0;
    cwd = {}
    for key in keywords:
        word2id[key] = currentId
        id2word[currentId] = key

        currentId = currentId+1
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:

        termlist = document[1].split()
        segList = [x.lower() for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        wordCount = {}

        for keyword in keywords:
            for word in segList:
                word = word.lower().strip()
                if(checkPurity(word)==True):
                    if(keyword  in word):

                        if keyword in wordCount:
                            wordCount[keyword] += 1
                        else:
                            wordCount[keyword] = 1


        #if(len(wordCount)>0):
        wordCounts.append(wordCount);

        N_test=N_test+1
    # length of dictionary
    M = len(keywords)

    # generate the document-word matrix
    X_test = zeros([N_test, M], int8)
    for word in word2id.keys():
        j = word2id[word]
        for i in range(0, N_test):
            if word in wordCounts[i]:
                X_test[i, j] = wordCounts[i][word];



    return N_test, X_test
def output():
    # document-topic distribution
    file = codecs.open(docTopicDist,'w','utf-8')
    for i in range(0, N):
        tmp = ''
        for j in range(0, K):
            tmp += str(lamda[i, j]) + ' '
        file.write(tmp + '\n')
    file.close()
    
    # topic-word distribution
    file = codecs.open(topicWordDist,'w','utf-8')
    for i in range(0, K):
        tmp = ''
        for j in range(0, M):
            tmp += str(theta[i, j]) + ' '
        file.write(tmp + '\n')
    file.close()
    
    # dictionary
    file = codecs.open(dictionary,'w','utf-8')
    for i in range(0, M):
        file.write(id2word[i] + '\n')
    file.close()
    
    # top words of each topic
    file = codecs.open(topicWords,'w','utf-8')
    for i in range(0, K):
        topicword = []
        ids = theta[i, :].argsort()
        for j in ids:   #Only numeric ids of corrsponding terms
            topicword.insert(0, id2word[j])
        tmp = ''
        for word in topicword[0:min(topicWordsNum, len(topicword))]:
            tmp += word + ' '
        file.write(tmp + '\n')
    file.close()
def F1Caclculate(accurate, detected, total):
    p = accurate/detected
    print("Precisionz: ", p)
    r = accurate/total
    f1 = 2*(p*r/(p+r))
    return f1
def Correctpredict(sampl):
    # update theta
    newTheta = np.zeros(K)
    for k in range(0, K):
        denominator = 0
        for j in range(0, M):
            newTheta [k] += theta[k,j]*sampl[j]
            denominator += theta[k, j]
    indx = np.argmax(newTheta)

    return indx

def dataset(datasetFilePath):
    csvfile = open(datasetFilePath, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    dataset = []
    for row in reader:
        dataset.append(row)
    return dataset

# set the default params and read the params from cmd
datasetFilePath = 'archiset.txt'
stopwordsFilePath = 'stopwords.dic'
testing= "C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/test_detect.csv"
training_sample  = "C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv"
K = 3    # number of topic
train_data = dataset(training_sample)
samples = len(train_data)
maxIteration = 30
threshold = 10.0
topicWordsNum = 10
docTopicDist = 'docTopicDistribution.txt'
topicWordDist = 'topicWordDistribution.txt'
dictionary = 'dictionary.dic'
topicWords = 'topics.txt'

choice = int(input("Enter option:"))
if(choice==1):
    probability(uniqueTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/unique.csv",readTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/saccsterm.csv")), "C:/labwork/forked_worked/archidata/archichange/goldenset/combined.csv","C:/labwork/forked_worked/archidata/archichange/goldenset/prob.csv")
if(choice == 2):
    terms = readTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/significant.csv")
    subterms = list(findsubsets(terms, 3))
    
    print(len(subterms))
if(choice==3):
    acCommits(readTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/significant.csv"),"C:/labwork/forked_worked/archidata/archichange/goldenset/combined.csv")
if(choice == 4):
    print("------Train and test start----------")

if(len(sys.argv) == 11):
    datasetFilePath = sys.argv[1]
    stopwordsFilePath = sys.argv[2]
    K = int(sys.argv[3])
    maxIteration = int(sys.argv[4])
    threshold = float(sys.argv[5])
    topicWordsNum = int(sys.argv[6])
    docTopicDist = sys.argv[7]
    topicWordDist = sys.argv[8]
    dictionary = sys.argv[9]
    topicWords = sys.argv[10]

# preprocessing
lamda = random([samples, K])
N, M, word2id, id2word, X= cwdcdMeasure(allwords_path, training_sample, "perfective")#preprocessing(datasetFilePath, stopwordsFilePath)

#Need to fix this instead randomize
# lamda[i, j] : p(zj|di)
#lamda = random([N, K]) #Here N is the documents

# theta[i, j] : p(wj|zi)
theta = random([K, M]) #M is the keywords This should be probability of a word beign in k devided by probability in not k
thetaMeasure(allwords_path, training_sample, "perfective")
# p[i, j, k] : p(zk|di,wj)
p = zeros([N, M, K])

#initializeParameters()

# EM algorithm
oldLoglikelihood = 1
newLoglikelihood = 1
for i in range(0, maxIteration):
    EStep()
    MStep()
    newLoglikelihood = LogLikelihood()
    print("[", time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), "] ", i+1, " iteration  ", str(newLoglikelihood))
    if(oldLoglikelihood != 1 and newLoglikelihood - oldLoglikelihood < threshold):
        break
    oldLoglikelihood = newLoglikelihood
N_test, tests = testSamples(allwords_path, testing)

ii=0

datas = dataset(testing)
#Here, 0: corrective
#1: perfective
#2: preventive or adaptive
category = ["corrective","perfective","adaptive preventive"]
prediction = []
correct_y = 0
correct_de = 0
adap_y = 0
adap_de = 0
prevent_y = 0
prevent_de = 0
perfect_y=0
perfect_de = 0
for i, sampl in enumerate(tests):
    indx = Correctpredict(sampl)
    if (datas[i][TEST_INDX].lower() in "corrective"):
        correct_tot = correct_tot + 1
    if (datas[i][TEST_INDX].lower() in "preventive" or datas[i][TEST_INDX].lower() in "adaptive"):
        prevent_tot = prevent_tot + 1
    if (datas[i][TEST_INDX].lower() in "adaptive"):
        adap_tot = adap_tot + 1
    if (datas[i][TEST_INDX].lower() in "perfective"):
        perfect_tot = perfect_tot + 1

    if (category[indx] in "corrective"):
        correct_de = correct_de + 1
    if (category[indx] in "preventive" or category[indx] in "adaptive"):
        prevent_de = prevent_de + 1
    if (category[indx] in "adaptive"):
        adap_de = adap_de + 1
    if (category[indx] in "perfective"):
        perfect_de = perfect_de + 1
    if(datas[i][TEST_INDX].lower() in category[indx] ):
        if(category[indx] in "corrective"):
            correct_y = correct_y + 1
        if (category[indx] in "preventive" or category[indx] in "adaptive"):
            prevent_y = prevent_y + 1
        if (category[indx] in "adaptive"):
            adap_y = adap_y + 1
        if (category[indx] in "perfective"):
            perfect_y = perfect_y + 1

        ii +=1

print(correct_tot)
print(adap_tot)
print(prevent_tot)
print(perfect_tot)
print("Accuracy: ", str(ii))
if(correct_y>0):
    correct_f1 = F1Caclculate(correct_y, correct_de, correct_tot)

    print("correct_f1: ", correct_f1)
#if(adap_y>0):
#    adap_f1 = F1Caclculate(adap_y, adap_de, adap_tot)
#    print("adap_f1: ", adap_f1)
if(prevent_y>0):
    prevent_f1 = F1Caclculate(prevent_y, prevent_de, prevent_tot)
    print("prevent_f1: ", prevent_f1)

if(perfect_y>0):
    perfect_f1=F1Caclculate(perfect_y, perfect_de, perfect_tot)
    print("perfect_f1: ", perfect_f1)
exit(0)
'''
for i in range(0, maxIteration):
    EStep()
    predict()
    newLoglikelihood = LogLikelihood()
    print("[", time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), "] ", i+1, " iteration  ", str(newLoglikelihood))
    if(oldLoglikelihood != 1 and newLoglikelihood - oldLoglikelihood < threshold):
        break
    oldLoglikelihood = newLoglikelihood
#output()
'''
print(theta)
