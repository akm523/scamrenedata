from numpy import zeros, int8, log
from pylab import random
import sys
from wordsegment import load, segment
import tfdf
#import jieba
import re
import time
import codecs
import string
import csv
from decimal import *
import numpy as np
import nltk
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
csv.field_size_limit(2**16)
# segmentation, stopwords filtering and document-word matrix generating
# [return]:
# N : number of documents
# M : length of dictionary
# word2id : a map mapping terms to their corresponding ids
# id2word : a map mapping ids to terms
# X : document-word matrix, N*M, each line is the number of terms that show up in the document
#nltk.download("stopwords")
from itertools import chain, combinations
CATEGORY_INDX = 5
AC_INDX = 4
'''adaptive_path = "04_07_18/adaptive.txt"
corrective_path="04_07_18/corrective.txt"
perfective_path="04_07_18/perfective.txt"
preventive_path="04_07_18/preventive.txt"
allwords_path="04_07_18/allkey.txt"
TRAIN_PATH = "04_07_18/train"
TEST_PATH = "04_07_18/test"
RULE_PATH = "04_07_18/rule"
'''
adaptive_path = "04_08_18/adaptive.dic"
corrective_path="04_08_18/corrective.dic"
perfective_path="04_08_18/perfective.dic"
preventive_path="04_08_18/preventive.txt"
allwords_path="04_08_18/allkey.txt"
TRAIN_PATH = "04_08_18/train"
TEST_PATH = "04_08_18/test"
RULE_PATH = "04_08_18/rule"
TRAIN_INDX = 5
TEST_INDX = 5
LABEL_INDEX = 5
def findsubsets(S,m):
    return set(combinations(S, m))

def powerset(iterable):
    """
    powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)
    """
    xs = list(iterable)
    # note we return an iterator rather than a list
    return chain.from_iterable(combinations(xs,n) for n in range(len(xs)+1))

def removeStopOrigin(word_list):
    filtered_word_list = word_list[:]  # make a copy of the word_list
    for word in word_list:  # iterate over word_list

        if word in stopwords.words('english'):
            filtered_word_list.remove(word)
    return filtered_word_list
def wordStemming(example_words):
    ps = PorterStemmer()
    words = []
    for w in example_words:
        wd = str(w)
        words.append(ps.stem(wd))
    return words

def dataset(datasetFilePath):
    csvfile = open(datasetFilePath, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    dataset = []
    for row in reader:
        dataset.append(row)
    return dataset

def dataStat(data):
    totalsamples =0
    adaptive  = 0
    preventive = 0
    perfective = 0
    corrective = 0
    for dat in data:
        print(dat[4])
        if("yes" in dat[4].lower()):
            totalsamples += 1
            if("adaptive" in dat[6].lower()):
                adaptive +=1
            if("corrective" in dat[6].lower()):
                corrective +=1
            if("preventive" in dat[6].lower()):
                preventive +=1
            if("perfective" in dat[6].lower()):
                perfective +=1
    print("Total: ", totalsamples)
    print("Adaptive: ", adaptive)
    print("Corrective: ", corrective)
    print("preventive: ", preventive)
    print("perfective: ", perfective)

#Make train set from CSV like
#topicname word1:count word2:count

def makeTrain(dataset):
    fo = open(TRAIN_PATH, 'w')
    for topic in range(len(dataset)):
      word_count = {}
      termlist = dataset[topic][1].split()
      termlist2 = [x.lower() for x in termlist]
      termlist3 = removeStopOrigin(termlist2)
      wordList2 = wordStemming(termlist3)
      for word in wordList2:
        if(checkPurity(word) == False):
                continue
        if(word in word_count):
            word_count[word] +=1
        else:
            word_count[word] = 1
      sort_list = sorted(word_count.items(), key=lambda d:-d[1])
      result_list = ['%s:%s' % (k, v) for k,v in sort_list]
      topic_name = "adaptive" if("preventive" in dataset[topic][TRAIN_INDX]) else dataset[topic][TRAIN_INDX]
      fo.write('%s %s\n' % (topic_name, ' '.join(result_list)))
    fo.close()

def makeTrainAC(dataset):
    fo = open(TRAIN_PATH, 'w')
    for topic in range(len(dataset)):
      word_count = {}
      termlist = dataset[topic][1].split()
      termlist2 = [x.lower() for x in termlist]
      termlist3 = removeStopOrigin(termlist2)
      wordList2 = wordStemming(termlist3)
      for word in wordList2:
        if(checkPurity(word) == False):
                continue
        if(word in word_count):
            word_count[word] +=1
        else:
            word_count[word] = 1
      sort_list = sorted(word_count.items(), key=lambda d:-d[1])
      result_list = ['%s:%s' % (k, v) for k,v in sort_list]
      topic_name = dataset[topic][TRAIN_INDX].lower()
      fo.write('%s %s\n' % (topic_name, ' '.join(result_list)))
    fo.close()

def frequency(dataset, save_path, type):
    fl = open(save_path, 'w' , newline='')
    csv_write = csv.writer(fl)
    word_count = {}
    sample = 0
    for topic in range(len(dataset)):

        if (type not in dataset[topic][4].lower() and (dataset[topic][5].lower() =='na')):
            continue
        sample = sample+1
        termlist = dataset[topic][1].split()
        termlist2 = [x.lower() for x in termlist]
        termlist3 = removeStopOrigin(termlist2)
        wordList2 = wordStemming(termlist3)
        for word in wordList2:
            if(checkPurity(word) == False):
                continue
            if(word in word_count):
                word_count[word] +=1
            else:
                word_count[word] = 1
    for term in word_count:
        py = float(word_count[term]/sample)
        #all = float(allterms[term]/allsample)
        csv_write.writerow([term, py])
    return word_count
def distinct(term1, term2, save_path):
    fl = open(save_path, 'w' , newline='')
    csv_write = csv.writer(fl)
    word_count = {}

    for topic in term1:
        if(topic not in term2):
            #all = float(allterms[term]/allsample)
            csv_write.writerow([topic, term1[topic]])

def makeTest(dataset):
    fo = open(TEST_PATH, 'w')
    fl = open("04_07_18/semi_test.csv", 'w', newline='')
    csv_write = csv.writer(fl)
    for topic in range(len(dataset)):
      word_count = {}

      termlist = dataset[topic][1].split()
      termlist2 = [x.lower() for x in termlist]
      termlist3 = removeStopOrigin(termlist2)
      wordList2 = wordStemming(termlist3)
      for word in wordList2:
        if(checkPurity(word) == False):
                continue
        if(word in word_count):
            word_count[word] +=1
        else:
            word_count[word] = 1
      sort_list = sorted(word_count.items(), key=lambda d:-d[1])
      result_list = ['%s:%s' % (k, v) for k,v in sort_list]
      #topic_name = "adaptive" if("preventive" in dataset[topic][4]) else dataset[topic][4]
      if(len(result_list)>1):
        csv_write.writerow([dataset[topic][0],dataset[topic][1], dataset[topic][TEST_INDX]])
        fo.write('%s%s\n' % (" ",' '.join(result_list)))
    fo.close()

def makeRule():
    fo = open(RULE_PATH, 'w')
    adaptive_keys = ""
    for line in open(adaptive_path):
        #print(line)
        adaptive_keys = adaptive_keys + ","+ line.strip()
    corrective_keys = ""
    for line in open(corrective_path):
        corrective_keys = corrective_keys + ","+ line.strip()
    perfecctive_keys = ""
    for line in open(perfective_path):
        perfecctive_keys = perfecctive_keys + ","+ line.strip()
    fo.write('%s%s\n' % ("adaptive ", adaptive_keys[1:]))
    fo.write('%s%s\n' % ("corrective ", corrective_keys[1:]))
    fo.write('%s%s\n' % ("perfective ", perfecctive_keys[1:]))
    fo.close()

def makeRuleAC():
    fo = open(RULE_PATH, 'w')
    adaptive_keys = ""
    for line in open(adaptive_path):
        #print(line)
        adaptive_keys = adaptive_keys + ","+ line.strip()
    preventive_keys = ""
    for line in open(preventive_path):
        #print(line)
        preventive_keys = preventive_keys + ","+ line.strip()
    corrective_keys = ""
    for line in open(corrective_path):
        corrective_keys = corrective_keys + ","+ line.strip()
    perfecctive_keys = ""
    for line in open(perfective_path):
        perfecctive_keys = perfecctive_keys + ","+ line.strip()
    fo.write('%s%s\n' % ("adaptive ", adaptive_keys[1:]))
    fo.write('%s%s\n' % ("preventive ", preventive_keys[1:]))
    fo.write('%s%s\n' % ("corrective ", corrective_keys[1:]))
    fo.write('%s%s\n' % ("perfective ", perfecctive_keys[1:]))
    fo.close()

def readTerms(file_path):
    csvfile = open(file_path, 'r' , encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    terms  = []
    for row in reader:
        str1 = str(row[0])

        terms.append(str1)
    return terms

def uniqueTerms(save_path, terms):
    fl = open( save_path, 'w')
    csv_write = csv.writer(fl)
    unique_word = set()
    for term in terms:
        termlist = term.split()
        termlist2 = [x.lower().strip(',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        termlist3 = removeStopOrigin(termlist2)
        wordList2 = wordStemming(termlist3)
        for key_word in wordList2:
            if(key_word not in unique_word):
                unique_word.add(key_word)
                csv_write.writerow([key_word])
    return list(unique_word)

def termSignificance(terms, filepath, save_path):

    csvfile = open(filepath, 'rb')
    reader = csv.reader(csvfile, delimiter=b',')
    fl = open(save_path, 'wb')
    csv_write = csv.writer(fl)
    commits =[]
    print(" C(T)-- AC(T) -- N(T)--act/ac")
    for row in reader:
        commits.append(row)
    #ct = len(commits)
    for term in terms:
        act = 0
        ct = 0
        ac = 0
        nt = 0
        wor = wordStemming([term])
        for commit in commits:
            text = commit[1]
            YN = commit[4]
            termlist = text.split()
            termlist2 = [x.lower().strip( ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
            termlist3 = removeStopOrigin(termlist2)
            wordList2 = wordStemming(termlist3)
            wor = wordStemming([term])

            if(wor[0] in wordList2):
                ct = ct +1
                if("Yes" in YN):
                    act = act +1
                else: nt = nt+1
            if("Yes" in YN):
                ac = ac + 1

        #sig = float(float(act/(ct*1)) + float(act/(ac*1)) - float(nt/(act*1)))

        if(nt == 0):
            powr =  float(Decimal(act)/Decimal(ac*1))
        else:
            powr = float(Decimal(act)/Decimal(ac*1) + Decimal(act)/Decimal(nt*1))
            if(act == 0):
                act = 1
            #powr = float(Decimal(act)/Decimal(ac*1) - Decimal(nt)/Decimal(act*1))
        if(powr>0.0):
            csv_write.writerow([wor[0], act, nt, powr])
            #print(wor[0] + " " + str(ct) + " " + str(act) + " " + str(nt) + " "+str(float((act*100)/(ac*1)))+" "+ str(powr))

def probability(terms, doclistpath, save_path):
    csvfile = open(doclistpath, 'r' , encoding="utf8",errors='ignore')
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N = 0
    wordCounts = [];
    occured = {}
    notoccured = {}
    allterms  = {}
    currentId = 0;
    cwd = {}
    print(terms)
    fl = open(save_path, 'w')
    csv_write = csv.writer(fl)
    for key in terms:
        occured[key] = currentId
        notoccured[key] = currentId
        allterms[key] = currentId
    ysample = 0
    nsample = 0
    allsample = 0
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:
        #load()
        cd = 0

        cwd['perfective'] = 0
        cwd['adaptive'] = 0
        cwd['corrective'] = 0

        termlist = document[1].split()
        segList = [x.lower().strip(',.!?;)\(}{[]<>@#$%&^*~|-_=+\n') for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        #print(segList)
        #segList = jieba.cut(document)
        wordCount = {}
        if("yes" in document[4].lower()):
            ysample =ysample +1
        else:
            nsample = nsample +1

        for keyword in terms:
            for word in segList:
                #word = word.lower().strip()
                #print(word)
                word = word.lower().strip()
                #if len(word) > 1 and not re.search('[0-9]', word) and word not in stopwords:
                if(keyword  in word):
                    cd  = cd +1
                    if("yes" in document[4]):
                        occured[keyword] +=1


                    else:
                        notoccured[keyword] +=1

                    allterms[keyword] +=1
                    break
        allsample +=1
    print(ysample)
    for term in terms:
        py = float(occured[term]/ysample)
        npy = float(notoccured[term]/nsample)
        #all = float(allterms[term]/allsample)
        csv_write.writerow([term, py, npy, (py-npy)])


def cwdcdMeasure(wordlistpath, doclistpath, type):
    file = codecs.open('stopwords.dic', 'r', 'utf-8')
    stopwords = [line.strip() for line in file]
    # for doc in stopwords[:5]:
    #     print(doc)
    file.close()
    file = codecs.open(wordlistpath, 'r', 'utf-8')
    keywords = [key.strip() for key in file]
    keywords = wordStemming(keywords)
    file.close()
    # read the documents
    file = codecs.open("corrective.txt", 'r', 'utf-8')
    corrective_key = [corr.strip() for corr in file]
    corrective_key = wordStemming(corrective_key)
    file.close()
    file = codecs.open("adaptive.txt", 'r', 'utf-8')
    adaptive_key = [corr.strip() for corr in file]
    file.close()
    file = codecs.open("perfective.txt", 'r', 'utf-8')
    perfective_key = [corr.strip() for corr in file]
    perfective_key = wordStemming(perfective_key)
    file.close()
    csvfile = open(doclistpath, 'r' , encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N = 0
    wordCounts = [];
    word2id = {}
    id2word = {}
    currentId = 0;
    cwd = {}
    for key in keywords:
        word2id[key] = currentId
        id2word[currentId] = key

        currentId = currentId+1
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:
        #load()
        cd = 0

        cwd['perfective'] = 0
        cwd['adaptive'] = 0
        cwd['corrective'] = 0

        termlist = document[1].split()
        segList = [x.lower().strip( ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        #print(segList)
        #segList = jieba.cut(document)
        wordCount = {}

        for keyword in keywords:
            for word in segList:
                word = word.lower().strip()
                if len(word) > 1 and not re.search('[0-9]', word) and word not in stopwords:
                    if(keyword  in word):
                        cd  = cd +1
                        if keyword in wordCount:
                            wordCount[keyword] += 1
                        else:
                            wordCount[keyword] = 1
                        if("corrective" in document[4]):
                            cwd['corrective'] += 1
                        if("perfective" in document[4]):
                            cwd['perfective'] += 1
                        if("adaptive" in document[4] or "preventive" in document[4]):
                            cwd['adaptive'] += 1

        #if(len(wordCount)>0):
        wordCounts.append(wordCount)
        print(cwd)
        print(cd)
        cd = 1 if(cd==0) else cd
        lamda[N][0] = float(Decimal(cwd['corrective'])/Decimal(cd))
        lamda[N][1] =  float(Decimal(cwd['perfective'])/Decimal(cd))
        lamda[N][2] = float(Decimal(cwd['adaptive'])/Decimal(cd))
        N=N+1
    # length of dictionary
    M = len(keywords)

    # generate the document-word matrix
    X = zeros([N, M], int8)
    for word in word2id.keys():
        j = word2id[word]
        for i in range(0, N):
            if word in wordCounts[i]:
                X[i, j] = wordCounts[i][word];

    print(X)
    print(lamda)

    return N, M, word2id, id2word, X
def noCommnality(term, list1, list2, list3):
    if(term in list1 or term in list2 or term in list3):
        return False
    else: return True

def checkPurity(word):
    PURE = True
    for cha in word:
        if (cha not in string.ascii_letters):
            PURE = False
            break
    return PURE

def preprocessing(datasetFilePath):

    # read the stopwords file
    file = codecs.open('stopwords.dic', 'r', 'utf-8')
    stopwords = [line.strip() for line in file]
    # for doc in stopwords[:5]:
    #     print(doc)
    file.close()
    
    #csvfile = open(datasetFilePath, 'r' , encoding="utf8",errors='ignore')
    reader = dataset(datasetFilePath)#csv.reader(csvfile, delimiter=',')

    # number of documents
    N = 0

    wordCounts = []
    word2id = {}
    id2word = {}
    currentId = 0
    key_perfective = {}
    key_corrective = {}
    key_preventive = {}
    key_adaptive = {}
    wordCount = {}
    total =0
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    for document in reader:
        print(document[AC_INDX])
        if("yes" not in document[AC_INDX].lower() ):
            continue
        if(document[CATEGORY_INDX].lower() not in ["adaptive", "corrective","perfective","preventive"]):
            continue
        total +=1
        termlist = document[1].split()
        segList = [x.lower() for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)

        #segList = jieba.cut(document)
        #print(document[5])
        for word in segList:
            word = word.lower().strip()
            if(checkPurity(word) == False):
                continue
            if len(word) > 1 and not re.search('[0-9]', word) and word not in stopwords:               
                if word not in word2id.keys():
                    word2id[word] = currentId
                    id2word[currentId] = word
                    currentId += 1
                if word in wordCount:
                    wordCount[word] += 1
                else:
                    wordCount[word] = 1
                if("perfective" in document[CATEGORY_INDX].lower()):
                    #print(word)
                    if word not in key_perfective.keys():
                        key_perfective[word] =1
                    else: key_perfective[word] +=1
                if("corrective" in document[CATEGORY_INDX].lower()):
                    if word not in key_corrective.keys():
                        key_corrective[word] =1
                    else: key_corrective[word] +=1
                if("adaptive" in document[CATEGORY_INDX].lower()):
                    if word not in key_adaptive.keys():
                        key_adaptive[word] =1
                    else: key_adaptive[word] +=1
                if("preventive" in document[CATEGORY_INDX].lower()):
                    if word not in key_preventive.keys():
                        key_preventive[word] =1
                    else: key_preventive[word] +=1

    print("Total: ", str(total))
    #print(wordCount)
    fl = open("perfective_keyl1.csv", 'w')
    csv_write = csv.writer(fl)
    for key in key_perfective:
        if(noCommnality(key,key_corrective, key_adaptive, key_preventive )):
            writePValue(csv_write, key,key_perfective,wordCount[key] )
        #csv_write.writerow([key ,(key_perfective[key]/wordCount[key])])
    fl.close()
    fl = open("corrective_keyl1.csv", 'w')
    csv_write = csv.writer(fl)
    for key in key_corrective:
        if(noCommnality(key,key_perfective, key_adaptive, key_preventive )):
            writePValue(csv_write, key,key_corrective,wordCount[key] )
        #csv_write.writerow([key ,(key_corrective[key]/wordCount[key])])
    fl.close()
    fl = open("adaptive_keyl1.csv", 'w')
    csv_write = csv.writer(fl)
    for key in key_adaptive:
        if(noCommnality(key,key_perfective, key_corrective, key_preventive )):
            writePValue(csv_write, key,key_adaptive,wordCount[key] )
        #csv_write.writerow([key ,(key_adaptive[key]/wordCount[key])])
    fl.close()
    fl = open("preventive_keyl1.csv", 'w')
    csv_write = csv.writer(fl)
    for key in key_preventive:
        if(noCommnality(key,key_perfective, key_corrective, key_adaptive)):
            writePValue(csv_write, key,key_preventive,wordCount[key] )
       #csv_write.writerow([key ,(key_preventive[key]/wordCount[key])])
    fl.close()
def writePValue(csv_w, key, contain, denometor):
    if(denometor>0):
        csv_w.writerow([key ,(contain[key]/denometor)])

def initializeParameters():
    #for i in range(0, N):
    #   normalization = sum(lamda[i, :])
    #    for j in range(0, K):
    #       lamda[i, j] /= normalization;

    for i in range(0, K):
        normalization = sum(theta[i, :])
        for j in range(0, M):
            theta[i, j] /= normalization;

def thetaMeasure(wordlistpath, doclistpath, type):
    file = codecs.open('stopwords.dic', 'r', 'utf-8')
    stopwords = [line.strip() for line in file]
    # for doc in stopwords[:5]:
    #     print(doc)
    file.close()
    file = codecs.open(wordlistpath, 'r', 'utf-8')
    keywords = [key.strip() for key in file]
    keywords = wordStemming(keywords)
    file.close()
    # read the documents
    file = codecs.open("corrective.txt", 'r', 'utf-8')
    corrective_key = [corr.strip() for corr in file]
    corrective_key = wordStemming(corrective_key)
    file.close()
    file = codecs.open("adaptive.txt", 'r', 'utf-8')
    adaptive_key = [corr.strip() for corr in file]
    adaptive_key = wordStemming(adaptive_key)
    file.close()
    file = codecs.open("perfective.txt", 'r', 'utf-8')
    perfective_key = [corr.strip() for corr in file]
    perfective_key = wordStemming(perfective_key)
    file.close()
    csvfile = open(doclistpath, 'r' , encoding="utf8")
    reader = csv.reader(csvfile, delimiter=',')
    # number of documents
    N = 0
    wordCounts = [];
    word2id = {}
    id2word = {}
    currentId = 0
    thetacd_perfective= {}
    thetacd_adaptive= {}
    thetacd_corrective= {}
    notthetacd_perfective= {}
    notthetacd_adaptive= {}
    notthetacd_corrective= {}
    for key in keywords:
        thetacd_perfective[key] = 0
        thetacd_adaptive[key]= 0
        thetacd_corrective[key] = 0
        notthetacd_perfective[key] = 0
        notthetacd_adaptive [key]= 0
        notthetacd_corrective[key] = 0
    # generate the word2id and id2word maps and count the number of times of words showing up in documents
    #lamda = [samples][K]
    for document in reader:
        #load()
        cd = 0


        termlist = document[1].split()
        segList = [x.lower().strip( ',.!?;)(}{[]<>@#$%&^*~|-_=+') for x in termlist]
        segList = removeStopOrigin(segList)
        segList = wordStemming(segList)
        #print(segList)
        #segList = jieba.cut(document)
        wordCount = {}

        for keyword in keywords:
            for word in segList:
                word = word.lower().strip()
                if len(word) > 1 and not re.search('[0-9]', word) and word not in stopwords:
                    if(keyword  in word):
                        cd  = cd +1
                        if keyword not in word2id.keys():
                            word2id[keyword] = currentId;
                            id2word[currentId] = keyword;
                            currentId += 1;
                        if keyword in wordCount:
                            wordCount[keyword] += 1
                        else:
                            wordCount[keyword] = 1
                        if("corrective" in document[4] and keyword in corrective_key):
                            thetacd_corrective[keyword] += 1
                        else:  notthetacd_corrective[keyword] += 1
                        if("perfective" in document[4] and keyword in perfective_key):
                            thetacd_perfective[keyword] += 1
                        else: notthetacd_perfective[keyword] += 1
                        if("adaptive" in document[4] or "preventive" in document[4] and keyword in adaptive_key):
                            thetacd_adaptive[keyword] += 1
                        else: notthetacd_adaptive[keyword] += 1

        #if(len(wordCount)>0):
        m = 0

        for key in keywords:
            theta[0][m] = thetacd_corrective[key] if(notthetacd_corrective[key]==0) else thetacd_corrective[key]/notthetacd_corrective[key]
            theta[1][m] =thetacd_perfective[key] if(notthetacd_perfective[key] == 0) else thetacd_perfective[key]/notthetacd_perfective[key]
            theta[2][m] = thetacd_adaptive[key] if(notthetacd_adaptive[key] == 0) else thetacd_adaptive[key] /notthetacd_adaptive[key]
            m = m+1

        print(theta)
def EStep():
    for i in range(0, N):
        for j in range(0, M):
            denominator = 0;
            for k in range(0, K):
                p[i, j, k] = theta[k, j] * lamda[i, k];
                denominator += p[i, j, k];
            if denominator == 0:
                for k in range(0, K):
                    p[i, j, k] = 0;
            else:
                for k in range(0, K):
                    p[i, j, k] /= denominator;


# set the default params and read the params from cmd
datasetFilePath = 'archiset.txt'
stopwordsFilePath = 'stopwords.dic'
testing= "C:/labwork/forked_worked/archidata/archichange/goldenset/testsample.csv"
training_sample  = "C:/labwork/forked_worked/archidata/archichange/goldenset/trainsample.csv"
K = 3    # number of topic
samples = 39
maxIteration = 30
threshold = 5.0
topicWordsNum = 10
docTopicDist = 'docTopicDistribution.txt'
topicWordDist = 'topicWordDistribution.txt'
dictionary = 'dictionary.dic'
topicWords = 'topics.txt'
word2id={}
id2word ={}
lamda = random([samples, K])
N=0
M=0
#Need to fix this instead randomize
# lamda[i, j] : p(zj|di)
#lamda = random([N, K]) #Here N is the documents

# theta[i, j] : p(wj|zi)
theta = random([K, M]) #M is the keywords This should be probability of a word beign in k devided by probability in not k
# p[i, j, k] : p(zk|di,wj)
p = zeros([N, M, K])

if __name__ == "__main__":
    choice = int(input("Enter option:"))
    if(choice==1):
        probability(uniqueTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/unique.csv",readTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/saccsterm.csv")), "C:/labwork/forked_worked/archidata/archichange/goldenset/combined.csv","C:/labwork/forked_worked/archidata/archichange/goldenset/prob.csv")
    if(choice == 2):
        terms = readTerms("C:/labwork/forked_worked/archidata/archichange/goldenset/significant.csv")
        subterms = list(findsubsets(terms, 3))

        print(len(subterms))
    if(choice == 3):
        preprocessing("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv")
    if(choice == 4):
        dataStat(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/category_train.csv"))
    if(choice ==5):
        makeTrainAC(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv"))
    if(choice ==6):
        makeTest(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/test_detect.csv"))
    if(choice ==7):
        makeRule()
    if(choice==8):
        makeRuleAC()
    if(choice ==9):
        makeTrainAC(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/trainsample2.csv"))
    if(choice ==11):
        makeTrain(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv"))
    if(choice==10):
        yes_terms = frequency(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv"), "C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/yes.csv", "yes")
        no_terms = frequency(dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv"), "C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/no.csv", "no")
        distinct(yes_terms, no_terms, "C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/distinct.csv")
