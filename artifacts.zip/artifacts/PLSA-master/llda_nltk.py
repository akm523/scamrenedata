#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Labeled LDA using nltk.corpus.reuters as dataset
# This code is available under the MIT License.
# (c)2013 Nakatani Shuyo / Cybozu Labs Inc.
import archiplsa
import sys, string, random, numpy
from nltk.corpus import reuters
from llda import LLDA
from optparse import OptionParser
from functools import reduce
import nltk
import codecs
nltk.download('reuters')
parser = OptionParser()
parser.add_option("--alpha", dest="alpha", type="float", help="parameter alpha", default=0.15)
parser.add_option("--beta", dest="beta", type="float", help="parameter beta", default=0.15)
parser.add_option("-k", dest="K", type="int", help="number of topics", default=4)
parser.add_option("-i", dest="iteration", type="int", help="iteration count", default=20)
parser.add_option("-s", dest="seed", type="int", help="random seed", default=None)
parser.add_option("-n", dest="samplesize", type="int", help="dataset sample size", default=100)
(options, args) = parser.parse_args()
random.seed(options.seed)
numpy.random.seed(options.seed)

adaptive_path = "nocommon/adaptive.txt"
corrective_path="nocommon/corrective.txt"
perfective_path="nocommon/perfective.txt"
preventive_path="nocommon/preventive.txt"
allwords_path="nocommon/allkey.txt"
'''
adaptive_path = "adaptive.dic"
corrective_path="corrective.dic"
perfective_path="perfective.dic"
preventive_path="preventive.dic"
allwords_path="allkey.txt"
'''
TRAIN_INDX = 5
TEST_INDX = 1
LABEL_INDEX = 5
idlist = random.sample(reuters.fileids(), options.samplesize)

def makeLabelWords():
    file = codecs.open(corrective_path, 'r', 'utf-8')
    corrective_key = [corr.strip() for corr in file]
    corrective_key = archiplsa.wordStemming(corrective_key)
    file.close()
    file = codecs.open(adaptive_path, 'r', 'utf-8')
    adaptive_key = [corr.strip() for corr in file]
    adaptive_key = archiplsa.wordStemming(adaptive_key)
    file.close()
    file = codecs.open(perfective_path, 'r', 'utf-8')
    perfective_key = [corr.strip() for corr in file]
    perfective_key = archiplsa.wordStemming(perfective_key)
    file.close()
    all_labels = []
    all_labels.append(corrective_key)
    all_labels.append(perfective_key)
    all_labels.append(adaptive_key)
    return  all_labels

def makeLabelWordsAC():
    file = codecs.open(corrective_path, 'r', 'utf-8')
    corrective_key = [corr.strip() for corr in file]
    corrective_key = archiplsa.wordStemming(corrective_key)
    file.close()
    file = codecs.open(adaptive_path, 'r', 'utf-8')
    adaptive_key = [corr.strip() for corr in file]
    adaptive_key = archiplsa.wordStemming(adaptive_key)
    file.close()
    file = codecs.open(perfective_path, 'r', 'utf-8')
    perfective_key = [corr.strip() for corr in file]
    perfective_key = archiplsa.wordStemming(perfective_key)
    file.close()
    file = codecs.open(preventive_path, 'r', 'utf-8')
    preventive_key = [corr.strip() for corr in file]
    preventive_key = archiplsa.wordStemming(preventive_key)
    file.close()
    all_labels = []
    all_labels.append(corrective_key)
    all_labels.append(perfective_key)

    all_labels.append(adaptive_key)
    all_labels.append(preventive_key)
    return  all_labels

def makeSamples(dataset):
    corps = []
    labels = []
    for topic in dataset:

      termlist = topic[1].split()
      labels.append(topic[LABEL_INDEX].lower())
      termlist2 = [x.lower() for x in termlist]
      termlist3 = archiplsa.removeStopOrigin(termlist2)
      wordList2 = archiplsa.wordStemming(termlist3)
      terms = [x for x in wordList2 if(archiplsa.checkPurity(x))]
      corps.append(terms)
    return corps, labels
def F1Caclculate(accurate, detected, total):
    p = accurate/detected
    print("precision: %s"%p)
    r = accurate/total
    f1 = 2*(p*r/(p+r))
    return f1
def testPredictAC(topic_words, labelset, corpus, llda,test_lbl):
    category = []
    category.append("corrective")
    category.append("perfective")
    category.append("adaptive")
    category.append("preventive")
    phi = llda.phi()
    label_to_top = [0]*len(labelset)
    topic_phi = [0]*4
    for k, label in enumerate(labelset):
        for zi, topic in enumerate(topic_words):
            if(label in topic):
                #print(label)
                label_to_top[k] = zi
                break
    #for top in llda.n_m_z:
    #Predicting the test set
    correct_tot = 0
    adap_tot = 0
    prevent_tot = 0
    perfect_tot = 0
    total = 0
    correct_y = 0
    correct_de = 0
    adap_y = 0
    adap_de = 0
    prevent_y = 0
    prevent_de = 0
    perfect_y = 0
    perfect_de = 0
    for i, corp in enumerate(corpus):
        if (test_lbl[i].lower() in "corrective"):
            correct_tot = correct_tot + 1
        if (test_lbl[i].lower() in "preventive"):
            prevent_tot = prevent_tot + 1
        if (test_lbl[i].lower() in "adaptive"):
            adap_tot = adap_tot + 1
        if (test_lbl[i].lower() in "perfective"):
            perfect_tot = perfect_tot + 1

        predict = numpy.zeros(len(labelset))
        topic_phi = [0]*4
        for k, label in enumerate(labelset):
            for w in corp:
                if(w in llda.vocas):
                    ind = llda.vocas.index(w)
                    predict[k]+= phi[k,ind]
                    topic_phi[label_to_top[k]] += predict[k]
        indx = numpy.argmax(topic_phi)
        #print("class: ",test_lbl[mesg_no])

        if (category[indx] in "corrective"):
            correct_de = correct_de + 1
        if (category[indx] in "preventive"):
            prevent_de = prevent_de + 1
        if (category[indx] in "adaptive"):
            adap_de = adap_de + 1
        if (category[indx] in "perfective"):
            perfect_de = perfect_de + 1
        if(category[indx] in test_lbl[i]):
            total +=1
            if (category[indx] in "corrective"):
                correct_y = correct_y + 1
            if (category[indx] in "preventive"):
                prevent_y = prevent_y + 1
            if (category[indx] in "adaptive"):
                adap_y = adap_y + 1
            if (category[indx] in "perfective"):
                perfect_y = perfect_y + 1

    print(correct_tot)
    print(adap_tot)
    print(prevent_tot)
    print(perfect_tot)
    print("Accuracy: ", str(total))
    if (correct_y > 0):
        correct_f1 = F1Caclculate(correct_y, correct_de, correct_tot)

        print("correct_f1: ", correct_f1)
    if (adap_y > 0):
        adap_f1 = F1Caclculate(adap_y, adap_de, adap_tot)
        print("adap_f1: ", adap_f1)
    if (prevent_y > 0):
        prevent_f1 = F1Caclculate(prevent_y, prevent_de, prevent_tot)
        print("prevent_f1: ", prevent_f1)

    if (perfect_y > 0):
        perfect_f1 = F1Caclculate(perfect_y, perfect_de, perfect_tot)
        print("perfect_f1: ", perfect_f1)
    print("accuracy: %s",str(total))


def testPredict(topic_words, labelset, corpus, llda,test_lbl):
    category = []
    category.append("corrective")
    category.append("perfective")
    category.append("adaptive")
    phi = llda.phi()
    label_to_top = [0]*len(labelset)
    topic_phi = [0]*3
    for k, label in enumerate(labelset):
        for zi, topic in enumerate(topic_words):
            if(label in topic):
                #print(label)
                label_to_top[k] = zi
                break
    #for top in llda.n_m_z:
    #Predicting the test set
    correct_tot = 0
    adap_tot = 0
    prevent_tot = 0
    perfect_tot = 0
    total = 0
    correct_y = 0
    correct_de = 0
    adap_y = 0
    adap_de = 0
    prevent_y = 0
    prevent_de = 0
    perfect_y = 0
    perfect_de = 0
    for i, corp in enumerate(corpus):
        predict = numpy.zeros(len(labelset))
        topic_phi = [0]*3
        if (test_lbl[i].lower() in "corrective"):
            correct_tot = correct_tot + 1
        if (test_lbl[i].lower() in "preventive" or test_lbl[i].lower() in "adaptive"):
            prevent_tot = prevent_tot + 1
        if (test_lbl[i].lower() in "adaptive"):
            adap_tot = adap_tot + 1
        if (test_lbl[i].lower() in "perfective"):
            perfect_tot = perfect_tot + 1
        for k, label in enumerate(labelset):
            for w in corp:
                if(w in llda.vocas):
                    ind = llda.vocas.index(w)
                    predict[k]+= phi[k,ind]
                    topic_phi[label_to_top[k]] += predict[k]
        indx = numpy.argmax(topic_phi)
        #print("class: ",test_lbl[mesg_no])
        if (category[indx] in "corrective"):
            correct_de = correct_de + 1
        if (category[indx] in "preventive" or category[indx] in "adaptive"):
            prevent_de = prevent_de + 1
        if (category[indx] in "adaptive"):
            adap_de = adap_de + 1
        if (category[indx] in "perfective"):
            perfect_de = perfect_de + 1
        if(category[indx] in test_lbl[i]):
            total +=1
            if (category[indx] in "corrective"):
                correct_y = correct_y + 1
            if (category[indx] in "preventive" or category[indx] in "adaptive"):
                prevent_y = prevent_y + 1
            if (category[indx] in "adaptive"):
                adap_y = adap_y + 1
            if (category[indx] in "perfective"):
                perfect_y = perfect_y + 1

    print(correct_tot)
    print(adap_tot)
    print(prevent_tot)
    print(perfect_tot)
    print("Accuracy: ", str(total))
    if (correct_y > 0):
        correct_f1 = F1Caclculate(correct_y, correct_de, correct_tot)

        print("correct_f1: ", correct_f1)
    #if (adap_y > 0):
    #    adap_f1 = F1Caclculate(adap_y, adap_de, adap_tot)
    #    print("adap_f1: ", adap_f1)
    if (prevent_y > 0):
        prevent_f1 = F1Caclculate(prevent_y, prevent_de, prevent_tot)
        print("prevent_f1: ", prevent_f1)

    if (perfect_y > 0):
        perfect_f1 = F1Caclculate(perfect_y, perfect_de, perfect_tot)
        print("perfect_f1: ", perfect_f1)
    print("accuracy: %s", str(total))

labels = []
corpus = []
#print(idlist)
LABELS = [['fix','bug'],['change','add'],['move','cleanup','test'],['fix', 'bug'],['change','add'],['move','cleanup', 'test']]
train_corpus, train_lbl = makeSamples(archiplsa.dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/combined.csv"))
#LABEL_INDEX=2
test_corpus, test_lbl = makeSamples(archiplsa.dataset("C:/labwork/forked_worked/archidata/archichange/goldenset/train_test/test_detect.csv"))
print("test: " ,test_lbl)
COPS = [
        "fix old jobparam hack for importing files to library bug",
            "Change python print() format to be backward compatible with older versions",
        "Move load plan implementations from spi to internal",
    "which ideally enable a user to classify a bug precisely to an area ",
        "Add makefile target for release process",
    "Cleanup common ui elements, add test cases move"
]
'''
for id in idlist:
    lbl_name = reuters.categories(id)
    print("lbl::::", lbl_name)
    labels.append(lbl_name)
    #print(reuters.words(id))
    crp1 = [x.lower() for x in reuters.words(id) if x[0] in string.ascii_letters]
    print("crp:::", crp1)
    corpus.append(crp1)
    reuters.words(id).close()
'''
label_ids = {}
label_ids["corrective"] = 0
label_ids["perfective"] = 1
label_ids["adaptive"] = 2
label_ids["preventive"] = 3
#label_words = makeLabelWords()
label_words = makeLabelWordsAC()

########
'''
for id in range(0, len(COPS)):

   # labels.append(LABELS[id])
    #print(reuters.words(id))
    termlist = COPS[id].split()
    segList = [x.lower().strip(',.!?;)\(}{[]<>@#$%&^*~|-_=+\n') for x in termlist]
    crp1 = [x.lower() for x in segList if x[0] in string.ascii_letters]
    crp1 = archiplsa.removeStopOrigin(crp1)
    print("crp:::", crp1)
    corpus.append(crp1)
    #reuters.words(id).close()
'''
#print(labels)

'''
for lbl in train_lbl:
    #print(lbl)
    if("preventive" in lbl):
        labels.append(label_words[2])
    elif(lbl in label_ids):
        labels.append(label_words[label_ids[lbl]])
    else:
        #labels.append([" "])
        print(lbl)
'''
for lbl in train_lbl:
    #print(lbl)
    if(lbl in label_ids):
        labels.append(label_words[label_ids[lbl]])
    else:
        #labels.append([" "])
        print(lbl)
print(len(labels))
labelset = list(set(reduce(list.__add__, labels)))
#labelset = labels
#print(corpus)
llda = LLDA(options.K, options.alpha, options.beta)
#llda.set_corpus(labelset, corpus, labels)
llda.set_corpus(labelset, train_corpus, labels)

print("M=%d, V=%d, L=%d, K=%d" % (len(corpus), len(llda.vocas), len(labelset), options.K))
print(len(test_lbl))
for i in range(options.iteration):
    #sys.stderr.write("-- %d : %.4f\n" % (i, llda.perplexity()))
    llda.inference()
#print("perplexity : %.4f" % llda.perplexity())

#testPredict(label_words,labelset, test_corpus, llda, test_lbl)
testPredictAC(label_words,labelset, test_corpus, llda, test_lbl)

exit(0)

#########################################################
phi = llda.phi()
print(len(phi))
for k, label in enumerate(labelset):
    print("\n-- label %d : %s" % (k, label))
    #print(numpy.argsort(-phi[k]))
    #for w in numpy.argsort(-phi[k])[:20]:
    #    print("%s: %.4f" % (llda.vocas[w], phi[k,w]))
#phi = llda.phi()
print(llda.n_z_t)
ii = 0
for z in llda.n_m_z:
    topic = numpy.argmax(z) #[llda.vocas[ind] if(ind !=0) else "" for ind in z ]

    print(labelset[topic])


topic_words = [['fix','bug'],['change','add'],['move','cleanup','test']]
label_to_top = [0]*len(labelset)
topic_phi = [0]*3
for k, label in enumerate(labelset):
    for zi, topic in enumerate(topic_words):
        if(label in topic):
            #print(label)
            label_to_top[k] = zi
            break
#for top in llda.n_m_z:
#Predicting the test set

for corp in corpus:
    predict = numpy.zeros(len(labelset))
    topic_phi = [0]*3
    for k, label in enumerate(labelset):
        for w in corp:
            if(w in llda.vocas):
                ind = llda.vocas.index(w)
                predict[k]+= phi[k,ind]
                topic_phi[label_to_top[k]] += predict[k]
    category = numpy.argmax(topic_phi)
    print("class: ",topic_words[category])

for v, voca in enumerate(llda.vocas):
    print(str(voca))
    print(llda.n_z_t[:,v])
    #print(','.join([voca]+[str(x) for x in llda.n_z_t[:,v]]))
    #print(','.join([voca]+[str(x) for x in phi[:,v]]))




